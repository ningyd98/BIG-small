"""Private model-key persistence; all credentials are fictional temporary fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from cloud_edge_robot_arm.cloud.api.app import create_app
from cloud_edge_robot_arm.cloud.planning.adapter import MockPlannerAdapter
from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
from cloud_edge_robot_arm.model_control.models import PlannerProviderKind
from cloud_edge_robot_arm.model_control.secret_store import InMemorySecretStore
from cloud_edge_robot_arm.model_control.service import ModelControlService
from cloud_edge_robot_arm.model_control.sqlite_repository import SQLiteModelProfileRepository

FIXTURE_VALUE = "r489-fictional-credential-for-private-temporary-tests"
PREFIX = "/api/v1/model-control"


@pytest.fixture(autouse=True)
def isolated_configuration(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("MODEL_CONTROL_SECRET_DIR", raising=False)
    monkeypatch.delenv("MODEL_CONTROL_SECRET_STORE", raising=False)
    monkeypatch.setenv("MODEL_CONTROL_DB", str(tmp_path / "profiles.db"))
    monkeypatch.setenv("DASHBOARD_AUTH_MODE", "LOCAL_ONLY")
    monkeypatch.setenv("BIGSMALL_VLM_ALLOW_PAID_CALL", "false")


def _app():
    return create_app(PlanningPipeline(planner=MockPlannerAdapter()))


def test_existing_active_profile_key_survives_new_api_instance() -> None:
    app = _app()
    with TestClient(app) as client:
        created_response = client.post(PREFIX + "/profiles", json={
            "display_name": "Existing cloud model",
            "provider_kind": "OPENAI_COMPATIBLE",
            "model_name": "fictional-model",
            "base_url": "https://api.example.test",
        })
        assert created_response.status_code == 201
        created = created_response.json()
        profile_id = created["profile_id"]
        assert client.post(f"{PREFIX}/profiles/{profile_id}/activate").status_code == 200
        updated_response = client.patch(f"{PREFIX}/profiles/{profile_id}",
                                        json={"api_key": FIXTURE_VALUE})
        assert updated_response.status_code == 200
        assert updated_response.json()["api_key"] is None
    del app
    new_app = _app()
    with TestClient(new_app) as client:
        recovered = client.get(PREFIX + "/profiles").json()[0]
        internal_key_recovered = (
            new_app.state.model_control_service.secret_store.get_secret(profile_id)
            == FIXTURE_VALUE
        )
        assert internal_key_recovered
        assert recovered["secret_present"] is True
        assert recovered["secret_store_kind"] == "ENCRYPTED_FILE"
        assert recovered["api_key"] is None
        assert recovered["active"] is True
        for key in ("profile_id", "display_name", "base_url", "model_name"):
            assert recovered[key] == created[key]
        assert FIXTURE_VALUE not in str(recovered)


def test_recreated_session_service_reports_actual_missing_key(tmp_path: Path) -> None:
    repository = SQLiteModelProfileRepository(tmp_path / "session.db")
    service = ModelControlService(repository=repository, secret_store=InMemorySecretStore())
    profile = service.create_profile(display_name="Session model",
        provider_kind=PlannerProviderKind.RULE_BASED, model_name="rule-based",
        api_key=FIXTURE_VALUE)
    recreated = ModelControlService(repository=repository, secret_store=InMemorySecretStore())
    assert recreated.get_profile(profile.profile_id).secret_present is False
    assert recreated.list_profiles()[0].secret_present is False
