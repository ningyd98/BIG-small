## Task 1：入口及账本 RED→GREEN

- [ ] 按plan.json接口写测试：七行固定分母；未知/重复/遗漏ID；重复组claim、跨案/组超限、预留落盘失败、开始后崩溃；负例云入口拦截不得PASS；原对象返回、同组一provider/逐案新session、初始后禁止reset/step、P同session两帧；无真值入在线参数。
- [ ] 保存预期RED后实现单脚本及薄launcher。launcher先原样调用R545 configure_overlay，再导入研究脚本；不复制/修改运行时。
- [ ] 新测试GREEN及Ruff/diff通过；用无模型的真实MuJoCo setup/capture检查七场景参数可执行，保存检查结果，不据此声称模型成功。

