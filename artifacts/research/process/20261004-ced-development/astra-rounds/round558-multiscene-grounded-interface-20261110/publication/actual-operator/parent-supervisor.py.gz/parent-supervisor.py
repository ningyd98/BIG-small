import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall')
raw = root / 'datasets/model-cache/molmo-multiscene-r558-r561-20261111'
execution = raw / 'execution'
group = sys.argv[1]
assert group in ('G1', 'G2', 'G3')
assert (raw / 'registry.json').is_file()
execution.mkdir(exist_ok=True)
prefix = execution / group.lower()
assert not prefix.with_suffix('.start.json').exists()
original = Path('/home/ningyd/文档/ChatGPT/BIGsmall')
args = [
    str(original / 'datasets/model-cache/ordered-small-vlm-20261109/runtimes/molmoer-r505/bin/python'),
    '-B',
    'artifacts/research/process/20261004-ced-development/astra-rounds/round558-multiscene-grounded-interface-20261110/implementation/launch_multiscene.py',
    'run-group', '--group', group,
    '--registry', 'artifacts/research/process/20261004-ced-development/astra-rounds/round558-multiscene-grounded-interface-20261110/preregistration.json',
    '--output', str(raw),
    '--model-directory', str(original / 'datasets/model-cache/ordered-small-vlm-20261109/models/Molmo2-ER'),
    '--asset-manifest', str(original / 'artifacts/research/process/20261004-ced-development/astra-rounds/round505-ordered-small-vlm-screen-20261109/candidates/04-molmoer/asset-manifest.json'),
    '--model-store', str(original / 'data/model_control.db'),
    '--profile-id', 'profile-4f24f5330ad644ad',
    '--gpu-lock', str(original / 'datasets/model-cache/zdtaichu5-9b-fp8-round473/research/.r468-r469-gpu.lock'),
    '--allow-paid',
]
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1', MUJOCO_GL='egl')
def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write_exclusive(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
started = time.monotonic()
write_exclusive(prefix.with_suffix('.start.json'), {
    'group': group, 'started_at': stamp(), 'cwd': str(root), 'command': args,
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'supervisor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'timeout_seconds': 240, 'retries': 0,
})
timed_out = False
with prefix.with_suffix('.stdout').open('xb') as stdout, prefix.with_suffix('.stderr').open('xb') as stderr:
    process = subprocess.Popen(args, cwd=root, env=env, stdout=stdout, stderr=stderr)
    try:
        code = process.wait(timeout=240)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.terminate()
        try:
            code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            code = process.wait()
    stdout.flush()
    stderr.flush()
    os.fsync(stdout.fileno())
    os.fsync(stderr.fileno())
result = {'group': group, 'pid': process.pid, 'ended_at': stamp(), 'elapsed_seconds': time.monotonic() - started, 'exit_code': code, 'timed_out': timed_out}
write_exclusive(prefix.with_suffix('.end.json'), result)
print(json.dumps(result), flush=True)
sys.exit(code if code >= 0 else 128 - code)
