from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

root = Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall')
raw = root / 'datasets/model-cache/molmo-multiscene-r558-r561-20261111'
public = root / 'artifacts/research/process/20261004-ced-development/astra-rounds/round558-multiscene-grounded-interface-20261110'
original = Path('/home/ningyd/文档/ChatGPT/BIGsmall')
def read(path):
    return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def exclusive(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
historical = read(raw / 'execution/prior-inventory.local.json')['files']
for row in historical:
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes']
    assert p.stat().st_mtime_ns == row['mtime_ns']
    assert sha(p) == row['sha256']
manifest_path = original / 'artifacts/research/process/20261004-ced-development/astra-rounds/round505-ordered-small-vlm-screen-20261109/candidates/04-molmoer/asset-manifest.json'
assert sha(manifest_path) == 'ff0563c87a9bd42a90df49db81dc14ee00d88894ad662f2b43c1942475076464'
assets = read(manifest_path)['files']
for row in assets:
    p = original / 'datasets/model-cache/ordered-small-vlm-20261109/models/Molmo2-ER' / row['Path']
    assert p.stat().st_size == row['Size']
    assert sha(p) == row['Sha256']
sealed = {}
for path in sorted(raw.glob('G*/raw-manifest.local.json')) + sorted(raw.glob('G*/*/case-evidence.manifest.json')):
    rows = read(path)['files']
    for row in rows:
        p = raw / row['path']
        assert p.resolve().is_relative_to(raw.resolve())
        assert p.stat().st_size == row['bytes']
        assert sha(p) == row['sha256']
    sealed[str(path.relative_to(raw))] = {'files_verified': len(rows), 'sha256': sha(path)}
groups = [read(raw / g / 'group-end.json') for g in ('G1', 'G2', 'G3')]
workers = [read(raw / 'execution' / (g.lower() + '.end.json')) for g in ('G1', 'G2', 'G3')]
for worker in workers:
    assert worker['exit_code'] == 0 and not worker['timed_out']
    try:
        os.kill(worker['pid'], 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError('worker PID still alive')
actual = {'loads': sum(g['actual_counts']['loads'] for g in groups), 'generations_started': sum(g['actual_counts']['generations_started'] for g in groups), 'generations_completed': sum(g['actual_counts']['generations_completed'] for g in groups)}
paid_keys = ('reserved', 'delegated_post', 'request_observed', 'response_observed', 'parsed_success')
actual['paid'] = {k: sum(g['accounting']['observed']['paid'][k] for g in groups) for k in paid_keys}
gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=name,memory.total,memory.free', '--format=csv,noheader'], text=True).strip()
compute = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader'], text=True).strip()
assert not compute
checks = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'historical_files_unchanged_sha_size_mtime': len(historical), 'model_asset_files_unchanged': len(assets), 'model_asset_manifest_sha256': sha(manifest_path), 'source_commit': '75f5a991fe16549843177a1fa79c76cf1914e741', 'registry_sha256': sha(raw / 'registry.json'), 'raw_manifests_verified': sealed, 'workers_exited': 3, 'worker_exit_codes': [w['exit_code'] for w in workers], 'actual': actual, 'unspent_reservations': {k: sum(g['accounting']['unspent'][k] for g in groups) for k in ('loads', 'generations', 'paid')}, 'cumulative_actual': {'loads': 4 + actual['loads'], 'generations_started': 10 + actual['generations_started'], 'paid_attempts': 2 + actual['paid']['delegated_post']}, 'gpu_after': gpu, 'foreign_compute_after': False, 'hardware_dispatch': False, 'physical_formal': 'NOT_RUN', 'scope': 'Byte integrity and accounting only; independent summary originally FAILED, not overridden by this audit.'}
exclusive(raw / 'execution/post-run-integrity.local.json', checks)
files = []
for p in sorted(raw.rglob('*')):
    if not p.is_file() or 'runtime-cache' in p.relative_to(raw).parts:
        continue
    files.append({'path': str(p.relative_to(raw)), 'bytes': p.stat().st_size, 'sha256': sha(p), 'mtime_ns': p.stat().st_mtime_ns})
full = {'schema': 'molmo.operator.full-inventory.v1', 'files': files, 'exclusions': ['runtime-cache', 'self'], 'does_not_replace_original_case_group_seals': True}
full_path = raw / 'raw-manifest.full.local.json'
exclusive(full_path, full)
checks['full_local_inventory'] = {'files': len(files), 'bytes': sum(r['bytes'] for r in files), 'sha256': sha(full_path), 'local_only': True}
exclusive(public / 'real-run-integrity.json', checks)
print(json.dumps({'historical_files_verified': len(historical), 'asset_files_verified': len(assets), 'raw_seals_verified': len(sealed), 'raw_files_inventoried': len(files), 'actual': actual, 'unspent': checks['unspent_reservations'], 'gpu_after': gpu}))
