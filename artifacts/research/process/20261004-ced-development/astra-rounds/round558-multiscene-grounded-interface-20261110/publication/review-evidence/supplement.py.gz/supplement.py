"""Additional CPU fault evidence for the same R558 initial review."""
from __future__ import annotations
import io,json,urllib.request
from contextlib import nullcontext
from datetime import UTC,datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from pytest import MonkeyPatch
from scripts import probe_molmo_multiscene as m
from cloud_edge_robot_arm.vision.grounded_planner import MolmoGroundedPlannerAdapter
from tests.test_molmo_grounded_planner import request_scene,cloud_fixture,FixturePoints
from tests.test_molmo_revalidation import rebuild
OUT=Path('/tmp/r558-review-evidence'); results={}
class Session:
    def __init__(self,config):pass
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def apply_scene(self,scene):pass
    def capture(self):return rebuild(request_scene().observation,captured_at=datetime.now(UTC))
class Points(FixturePoints):
    model_loads_started=1
    def __init__(self,**kwargs):
        super().__init__();self.generation_calls_started=0;self.generation_calls_completed=0
    def point(self,observation,phrase):
        self.generation_calls_started+=1;self.generation_calls_completed+=1
        return super().point(observation,phrase)
def factory(mp,malformed=False):
    def build(**kwargs):
        cloud,_=cloud_fixture(mp)
        if malformed:
            class Boundary:
                def open(self,*a,**kw):return io.BytesIO(b'not-json-after-HTTP-response')
            mp.setattr(urllib.request,'build_opener',lambda *a:Boundary())
        return MolmoGroundedPlannerAdapter(cloud=cloud,point_provider=kwargs['point_provider'],task=kwargs['task'],post_cloud_observation_supplier=kwargs['post_cloud_observation_supplier'])
    return build
with TemporaryDirectory() as temp,MonkeyPatch.context() as mp:
    root=Path(temp)/'run';cases=m.build_cases('a'*64);reg=m.preregister(root,cases,{})
    ledger=m.RunLedger(root,reg);ledger.claim('G1')
    for name in ['N01','N02']:ledger.begin_case('G1',name);ledger.end_case('G1',name)
    mp.setattr(m,'MuJoCoCaptureSession',Session);mp.setattr(m,'build_molmo_grounded_planner',factory(mp,True))
    response=m.run_case(cases[2],provider=Points(),service=object(),profile_id='fixture',ledger=ledger,output=root)
    events=ledger.events_for('P01');row=m.classify_case(cases[2],response,events)
    results['malformed_received_cloud']={'result':row,'events':events,'cloud_files':{p.name:p.read_text() for p in (root/'G1/P01/cloud').iterdir()},'paid_reservations':len(list((root/'reservations').glob('paid-*.json')))}
    ledger.close()
with TemporaryDirectory() as temp,MonkeyPatch.context() as mp:
    root=Path(temp)/'run';cases=m.build_cases('a'*64);reg=m.preregister(root,cases,{})
    mp.setattr(m,'MuJoCoCaptureSession',Session);mp.setattr(m,'build_molmo_grounded_planner',factory(mp))
    mp.setattr(m,'_check_sources',lambda *a:None);mp.setattr(m,'_profile',lambda *a:(object(),{}));mp.setattr(m,'_admit_resources',lambda *a:nullcontext({}))
    class FailingPoints(Points):
        def point(self,*a):
            self.generation_calls_started+=1
            raise RuntimeError('CPU native failure prevents any cloud call')
    mp.setattr(m,'MolmoPointProvider',FailingPoints)
    original=Path.mkdir; failed=[]
    def mkdir(path,*a,**kw):
        if path==root/'events/N01' and not failed:
            failed.append(True);raise OSError('CPU one-shot mkdir evidence persistence failure')
        return original(path,*a,**kw)
    mp.setattr(Path,'mkdir',mkdir)
    report=m.run_group('G1',registry=root/'registry.json',output=root,model_directory=root,asset_manifest=root/'fake',model_store=root/'fake',profile_id='fixture',gpu_lock=root/'lock',allow_paid=True)
    results['ledger_failure_continues']={'report':report,'case_starts':[p.name for p in (root/'claims').glob('case-*-start.json')],'events':{c.case_id:m.RunLedger(root,reg).events_for(c.case_id) for c in cases[:3]}}
(OUT/'supplement-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print('malformed_received_cloud',{'paid_responses':results['malformed_received_cloud']['result']['paid_responses'],'response_raw_saved':results['malformed_received_cloud']['cloud_files']['response-0001.json'],'paid_reservations':results['malformed_received_cloud']['paid_reservations']})
print('ledger_failure_continues',{'case_starts':results['ledger_failure_continues']['case_starts'],'status':report['status'],'counts':report['actual_counts']})
print('CPU fixtures only: actual native/cloud calls 0/0.')
