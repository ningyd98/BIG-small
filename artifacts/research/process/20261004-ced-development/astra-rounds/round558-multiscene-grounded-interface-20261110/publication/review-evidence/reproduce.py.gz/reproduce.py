"""Read-only CPU review probes. No model, real renderer, or network calls."""
from __future__ import annotations
import base64
import hashlib
import json
from contextlib import nullcontext
from datetime import UTC, datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import numpy as np
from pytest import MonkeyPatch
from scripts import probe_molmo_multiscene as m
from cloud_edge_robot_arm.vision.grounded_planner import MolmoGroundedPlannerAdapter
from tests.test_molmo_grounded_planner import request_scene, cloud_fixture, FixturePoints, refresh_fixture
from tests.test_molmo_revalidation import rebuild
from tests.test_molmo_multiscene import negative_response
from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline

OUT=Path('/tmp/r558-review-evidence')
findings={}

class Session:
    base=None
    def __init__(self, config): pass
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def apply_scene(self, scene): pass
    def capture(self):
        return rebuild(self.base, captured_at=datetime.now(UTC))

class CountedPoints(FixturePoints):
    model_loads_started=1
    def __init__(self,**kwargs):
        super().__init__()
        self.generation_calls_started=0
        self.generation_calls_completed=0
    def point(self,observation,phrase):
        self.generation_calls_started+=1
        self.generation_calls_completed+=1
        return super().point(observation,phrase)

def common(mp):
    mp.setattr(m,'MuJoCoCaptureSession',Session)
    def factory(**kwargs):
        cloud,_=cloud_fixture(mp)
        return MolmoGroundedPlannerAdapter(cloud=cloud,point_provider=kwargs['point_provider'],task=kwargs['task'],post_cloud_observation_supplier=kwargs['post_cloud_observation_supplier'])
    mp.setattr(m,'build_molmo_grounded_planner',factory)

# Actual original association rejects invalid original depth; actual pipeline is used.
with TemporaryDirectory(prefix='r558-r1-') as temp, MonkeyPatch.context() as mp:
    root=Path(temp)/'run'; cases=m.build_cases('a'*64); reg=m.preregister(root,cases,{})
    ledger=m.RunLedger(root,reg); ledger.claim('G1')
    ledger.begin_case('G1','N01'); ledger.end_case('G1','N01')
    base=request_scene().observation
    depth=np.asarray(base.depth_values(),dtype='<f4').reshape(base.height,base.width)
    depth[26,12]=0
    Session.base=rebuild(base,depth_float32_base64=base64.b64encode(depth.tobytes()).decode())
    common(mp)
    response=m.run_case(cases[1],provider=CountedPoints(),service=object(),profile_id='fixture',ledger=ledger,output=root)
    events=ledger.events_for('N02')
    findings['R1_invalid_original_depth']={'response':response.model_dump(mode='json'),'events':events,'classification':m.classify_case(cases[1],response,events)}
    ledger.close()

# Provider completes a simulated generation then fails persisting its raw evidence.
with TemporaryDirectory(prefix='r558-r2-') as temp, MonkeyPatch.context() as mp:
    root=Path(temp)/'run'; cases=m.build_cases('a'*64); reg=m.preregister(root,cases,{})
    Session.base=request_scene().observation
    common(mp)
    calls=[]
    class FailingProvider(CountedPoints):
        def point(self,observation,phrase):
            self.generation_calls_started+=1
            self.generation_calls_completed+=1
            calls.append(phrase)
            raise OSError('CPU injected raw-response persistence failure after generation completion')
    mp.setattr(m,'MolmoPointProvider',FailingProvider)
    mp.setattr(m,'_check_sources',lambda *a:None)
    mp.setattr(m,'_profile',lambda *a:(object(),{}))
    mp.setattr(m,'_admit_resources',lambda *a:nullcontext({}))
    report=m.run_group('G1',registry=root/'registry.json',output=root,model_directory=root,asset_manifest=root/'fake.json',model_store=root/'fake.db',profile_id='fixture',gpu_lock=root/'gpu.lock',allow_paid=True)
    findings['R2_provider_failure']={'report':report,'delegations':calls,'reservations':[json.loads(p.read_bytes()) for p in (root/'reservations').glob('*.json')],'events':{c.case_id:m.RunLedger(root,reg).events_for(c.case_id) for c in cases[:3]}}

# Directory creation is part of ledger persistence but outside its fatal handler.
with TemporaryDirectory(prefix='r558-r3-') as temp, MonkeyPatch.context() as mp:
    root=Path(temp)/'run'; cases=m.build_cases('a'*64); reg=m.preregister(root,cases,{})
    ledger=m.RunLedger(root,reg); ledger.claim('G1')
    mkdir=Path.mkdir
    def fail_mkdir(path,*a,**kw):
        if path==root/'events'/'N01': raise OSError('CPU injected event directory failure')
        return mkdir(path,*a,**kw)
    mp.setattr(Path,'mkdir',fail_mkdir)
    try: ledger.record('N01',kind='point',phase='start')
    except OSError as exc: error=str(exc)
    findings['R3_ledger_mkdir']={'error':error,'fatal':ledger.fatal}
    ledger.close()

# Existing original positive pipeline fixture, no start/closure events or raw files.
with MonkeyPatch.context() as mp:
    case=m.build_cases('a'*64)[2]
    state=refresh_fixture(mp); state.request.request_id=case.request_id
    response=PlanningPipeline(planner=state.adapter).process(state.request)
    checksums=[state.request.observation.checksum_sha256,state.captures[0].checksum_sha256]
    events=[{'kind':'capture','phase':'end','observation_checksum':v,'session_id':'same'} for v in checksums]
    events += [{'kind':'point','phase':'end','status':'POINT','bound':True,'observation_checksum':v,'actual_generation_delta':1} for v in checksums for _ in range(2)]
    events += [{'kind':'paid','phase':'end','model':'gpt-6.1-sol','response_received':True},{'kind':'point','phase':'start','observation_checksum':checksums[1]}]
    findings['R4_unclosed_events']={'classification':m.classify_case(case,response,events),'events':events,'scope':'Real CPU pipeline response, synthetic recorded terminal events plus unmatched point start; no native/cloud execution.'}

# CLI accepts seven verdict-only rows, with all actual evidence/claims/groups absent.
with TemporaryDirectory(prefix='r558-r4-') as temp:
    root=Path(temp)/'run'; cases=m.build_cases('a'*64); reg=m.preregister(root,cases,{})
    for case in cases:
        m._write(root/case.group_id/f'result-{case.case_id}.json',{'case_id':case.case_id,'verdict':'PASS_PLANNED' if case.expected=='positive' else 'PASS_EXPECTED_REJECTION','passed':False})
    rc=m.main(['summarize','--registry',str(root/'registry.json'),'--output',str(root)])
    findings['R4_summary_missing_raw']={'exit_code':rc,'summary':json.loads((root/'summary.local.json').read_bytes()),'manifest':json.loads((root/'raw-manifest.local.json').read_bytes())}

(OUT/'reproduction-results.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')
for name,result in findings.items():
    if 'classification' in result:
        print(name, result['classification'])
    elif 'report' in result:
        print(name, {'actual_counts':result['report']['actual_counts'],'case_counts':[r['actual_generations'] for r in result['report']['results']],'status':result['report']['status'],'delegations':len(result['delegations'])})
    elif 'summary' in result:
        print(name, {'exit_code':result['exit_code'],'all_cases_pass':result['summary']['all_cases_pass'],'raw_file_count':len(result['manifest']['files'])})
    else: print(name,result)
print('All probes are CPU-only; actual native loads/generations/cloud paid calls = 0/0/0.')
