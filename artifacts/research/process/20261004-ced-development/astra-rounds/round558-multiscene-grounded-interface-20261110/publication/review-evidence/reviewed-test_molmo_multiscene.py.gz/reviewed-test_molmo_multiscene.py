"""多场景研究入口的预算、分类和存证测试；不运行模型/网络。"""

from __future__ import annotations

import importlib
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

from cloud_edge_robot_arm.cloud.planning.models import InitialPlanningResponse


def api():
    return importlib.import_module("scripts.probe_molmo_multiscene")


def setup_run(tmp_path):
    module = api()
    cases = module.build_cases("a" * 64)
    root = tmp_path / "run"
    registry = module.preregister(root, cases, {})
    ledger = module.RunLedger(root, registry)
    return module, cases, root, registry, ledger


def test_seven_assignments_are_static_unique_and_parameterized_before_rendering():
    cases = api().build_cases("a" * 64)
    assert [case.case_id for case in cases] == ["N01", "N02", "P01", "N03", "P02", "N04", "P03"]
    assert [case.point_cap for case in cases] == [2, 2, 4, 2, 4, 2, 4]
    assert sum(case.paid_cap for case in cases) == 3
    assert len({case.request_id for case in cases}) == 7
    assert all(
        case.task.instruction == f"Move the {case.task.target_phrase} to the green region."
        for case in cases
    )
    assert all(case.scene.scene_parameters["depth_noise_m"] == 0 for case in cases)
    assert cases[0].task.target_phrase == "blue block"
    assert cases[0].scene.scene_parameters["target"]["color_name"] == "red"
    assert len(cases[1].scene.scene_parameters["distractors"]) == 1
    assert cases[3].scene.scene_parameters["destination"]["rgba"] == [0.5, 0.5, 0.5, 1]


def test_preregistration_requires_a_new_root_and_exclusively_seals_its_contents(tmp_path):
    module, cases, root, registry, _ = setup_run(tmp_path)
    assert len(registry["cases"]) == 7
    assert registry["raw_root"] == str(root.resolve())
    assert (root / "registry.json").is_file() and (root / "registry.sha256").is_file()
    with pytest.raises((FileExistsError, ValueError)):
        module.preregister(root, cases, {})


@pytest.mark.parametrize("variant", ["missing", "duplicate", "unknown"])
def test_summary_keeps_fixed_denominator_and_invalidates_unknown_or_duplicate(tmp_path, variant):
    module, _, _, registry, _ = setup_run(tmp_path)
    records = [{"case_id": row["case_id"], "verdict": "FAIL_TEST"} for row in registry["cases"]]
    if variant == "missing":
        records.pop()
    elif variant == "duplicate":
        records.append(records[0].copy())
    else:
        records.append({"case_id": "UNREGISTERED", "verdict": "PASS_PLANNED"})
    result = module.summarize(registry, records)
    assert (
        result["total_cases"] == 7
        and result["positive_cases"] == 3
        and result["negative_cases"] == 4
    )
    assert len(result["cases"]) == 7 and not result["all_cases_pass"]
    assert result["missing_cases"] == (1 if variant == "missing" else 0)
    assert result["duplicate_cases"] == (1 if variant == "duplicate" else 0)
    assert result["unknown_records"] == (1 if variant == "unknown" else 0)
    if variant != "missing":
        assert not result["valid_suite"]


def test_claim_is_exclusive_and_a_crashed_group_cannot_be_restarted(tmp_path):
    module, _, root, registry, ledger = setup_run(tmp_path)
    ledger.claim("G1")
    ledger.close()
    restarted = module.RunLedger(root, registry)
    with pytest.raises(ValueError, match="claim"):
        restarted.claim("G1")
    restarted.close()


def test_group_order_and_concurrent_group_are_rejected(tmp_path):
    module, _, root, registry, ledger = setup_run(tmp_path)
    with pytest.raises(ValueError):
        ledger.claim("G2")
    ledger.claim("G1")
    other = module.RunLedger(root, registry)
    with pytest.raises((ValueError, BlockingIOError)):
        other.claim("G2")
    other.close()
    ledger.close()


@pytest.mark.parametrize("kind,case_id", [("point", "P03"), ("paid", "N01"), ("load", "N01")])
def test_ledger_refuses_cross_group_and_forbidden_reservations(tmp_path, kind, case_id):
    _, _, _, _, ledger = setup_run(tmp_path)
    ledger.claim("G1")
    ledger.reserve("load", group_id="G1", case_id=None)
    ledger.begin_case("G1", "N01")
    with pytest.raises(ValueError):
        ledger.reserve(kind, group_id="G1", case_id=case_id)
    ledger.close()


def test_order_load_point_case_and_group_caps_are_durable(tmp_path):
    _, _, root, _, ledger = setup_run(tmp_path)
    ledger.claim("G1")
    ledger.reserve("load", group_id="G1", case_id=None)
    with pytest.raises(ValueError):
        ledger.reserve("load", group_id="G1", case_id=None)
    with pytest.raises(ValueError):
        ledger.begin_case("G1", "P01")
    for case_id, cap in [("N01", 2), ("N02", 2), ("P01", 4)]:
        ledger.begin_case("G1", case_id)
        for _ in range(cap):
            path = ledger.reserve("point", group_id="G1", case_id=case_id)
            assert path.is_file()
        with pytest.raises(ValueError):
            ledger.reserve("point", group_id="G1", case_id=case_id)
        if case_id == "P01":
            ledger.reserve("paid", group_id="G1", case_id=case_id)
            with pytest.raises(ValueError):
                ledger.reserve("paid", group_id="G1", case_id=case_id)
        ledger.end_case("G1", case_id)
    assert len(list((root / "reservations").glob("point-*.json"))) == 8
    ledger.close()


def test_reservation_write_failure_does_not_create_a_successful_start(tmp_path, monkeypatch):
    module, _, root, _, ledger = setup_run(tmp_path)
    ledger.claim("G1")
    original = module._write

    def fail(path, value):
        if path.parent == root / "reservations":
            raise OSError("injected disk failure")
        return original(path, value)

    monkeypatch.setattr(module, "_write", fail)
    with pytest.raises(OSError):
        ledger.reserve("load", group_id="G1", case_id=None)
    assert not list((root / "reservations").glob("load-*.json"))
    assert ledger.fatal
    ledger.close()


def negative_response(case):
    return InitialPlanningResponse(
        request_id=case.request_id,
        outcome="REQUEST_MORE_OBSERVATION",
        reason="fixture visual refusal",
        created_at=datetime.now(UTC),
    )


@pytest.mark.parametrize(
    "fault", ["cloud_entry", "budget_block", "runtime_error", "capture_gap", "INVALID"]
)
def test_test_boundary_and_runtime_failures_never_count_as_visual_rejection(fault):
    module = api()
    case = module.build_cases("a" * 64)[0]
    events = [
        {
            "kind": "point",
            "phase": "end",
            "status": "ABSENT",
            "bound": True,
            "actual_generation_delta": 1,
        }
    ]
    if fault == "INVALID":
        events[0]["status"] = "INVALID"
    else:
        events.append({"kind": fault})
    result = module.classify_case(case, negative_response(case), events)
    assert not result["passed"] and not result["verdict"].startswith("PASS")
    if fault == "cloud_entry":
        assert result["verdict"] == "FAIL_CLOUD_GATE_REACHED"


def test_valid_absence_and_original_geometry_rejections_are_classified_separately():
    module = api()
    case = module.build_cases("a" * 64)[0]
    absence = [
        {
            "kind": "point",
            "phase": "end",
            "status": "ABSENT",
            "bound": True,
            "actual_generation_delta": 1,
        }
    ]
    result = module.classify_case(case, negative_response(case), absence)
    assert (
        result["verdict"] == "PASS_EXPECTED_REJECTION"
        and result["refusal_source"] == "model_absence"
    )
    geometry = [
        {
            "kind": "point",
            "phase": "end",
            "status": "POINT",
            "bound": True,
            "actual_generation_delta": 1,
        }
    ] * 2
    geometry += [
        {
            "kind": "stage",
            "phase": "error",
            "stage": "tracker",
            "error_type": "ValueError",
            "visual_rejection": True,
        }
    ]
    result = module.classify_case(case, negative_response(case), geometry)
    assert result["passed"] and result["refusal_source"] == "program_geometry"


def test_a_positive_refusal_cannot_pass_as_a_negative():
    module = api()
    case = module.build_cases("a" * 64)[2]
    result = module.classify_case(case, negative_response(case), [])
    assert not result["passed"]


def test_run_case_preserves_original_response_and_uses_only_two_capture_calls(
    tmp_path, monkeypatch
):
    from tests.test_molmo_grounded_planner import request_scene
    from tests.test_molmo_revalidation import rebuild

    module, cases, root, _, ledger = setup_run(tmp_path)
    # Complete the preceding negative slots without running perception.
    ledger.claim("G1")
    ledger.reserve("load", group_id="G1", case_id=None)
    for name in ["N01", "N02"]:
        ledger.begin_case("G1", name)
        ledger.end_case("G1", name)
    case = cases[2]
    base = request_scene().observation
    calls = []

    class Session:
        def __init__(self, config):
            self.index = 0

        def __enter__(self):
            calls.append("open")
            return self

        def __exit__(self, *args):
            calls.append("close")

        def apply_scene(self, scene):
            assert self.index == 0
            calls.append("apply")

        def capture(self):
            self.index += 1
            calls.append("capture")
            return rebuild(base, frame_id=f"frame-{self.index}", captured_at=datetime.now(UTC))

        def step(self, *args):
            raise AssertionError("physics step forbidden")

        def reset(self, *args):
            raise AssertionError("reset forbidden after setup")

    original_response = negative_response(case)
    cloud = SimpleNamespace(
        _request_visual=lambda *a: {}, _post=lambda *a: {}, raw_transport_observer=None
    )
    adapter = SimpleNamespace(cloud=cloud, post_cloud_observation_supplier=None)

    def factory(**kwargs):
        assert kwargs["task"] is case.task
        adapter.post_cloud_observation_supplier = kwargs["post_cloud_observation_supplier"]
        return adapter

    class Pipeline:
        def __init__(self, *, planner):
            self.planner = planner

        def process(self, request):
            assert request.user_instruction == case.task.instruction
            assert request.scene.objects == [] and request.scene.robot_state == {}
            assert "instance_ids" not in request.model_dump_json()
            assert request.observation is not None
            self.planner.post_cloud_observation_supplier()
            return original_response

    monkeypatch.setattr(module, "MuJoCoCaptureSession", Session)
    monkeypatch.setattr(module, "build_molmo_grounded_planner", factory)
    monkeypatch.setattr(module, "PlanningPipeline", Pipeline)
    returned = module.run_case(
        case, provider=object(), service=object(), profile_id="fixture", ledger=ledger, output=root
    )
    assert returned is original_response
    assert calls == ["open", "apply", "capture", "capture", "close"]
    ledger.close()


def test_mutated_registry_is_rejected_before_any_claim_or_load(tmp_path):
    module, _, root, registry, _ = setup_run(tmp_path)
    registry["cases"][0]["point_cap"] = 100
    with pytest.raises(ValueError):
        module.RunLedger(root, registry)
    assert not list((root / "claims").glob("group-*.json"))


def test_one_group_constructs_one_provider_and_visits_every_assigned_case(tmp_path, monkeypatch):
    from contextlib import nullcontext

    module, _, root, _, _ = setup_run(tmp_path)
    external_registry = tmp_path / "frozen-registry.json"
    external_registry.write_bytes((root / "registry.json").read_bytes())
    calls = []

    class Provider:
        model_loads_started = 1
        generation_calls_started = 0
        generation_calls_completed = 0

        def __init__(self, **kwargs):
            calls.append(("load", kwargs["generation_limit"]))

    def run(case, *, provider, service, profile_id, ledger, output):
        ledger.begin_case(case.group_id, case.case_id)
        calls.append(("case", case.case_id, id(provider)))
        ledger.end_case(case.group_id, case.case_id)
        return negative_response(case)

    monkeypatch.setattr(module, "_check_sources", lambda registry: None)
    monkeypatch.setattr(module, "MolmoPointProvider", Provider)
    monkeypatch.setattr(module, "_admit_resources", lambda *a: nullcontext({}))
    monkeypatch.setattr(module, "_profile", lambda *a: (object(), {"secret_present": True}))
    monkeypatch.setattr(module, "run_case", run)
    result = module.run_group(
        "G1",
        registry=external_registry,
        output=root,
        model_directory=tmp_path,
        asset_manifest=tmp_path / "manifest.json",
        model_store=tmp_path / "store.db",
        profile_id="fixture",
        gpu_lock=tmp_path / "gpu.lock",
        allow_paid=True,
    )
    assert calls[0] == ("load", 8)
    assert [call[1] for call in calls[1:]] == ["N01", "N02", "P01"]
    assert len({call[2] for call in calls[1:]}) == 1
    assert result["actual_counts"]["loads"] == 1


@pytest.mark.parametrize(
    "damage", [None, "binding", "frames", "final_gate", "paid", "query_count", "exception"]
)
def test_positive_requires_original_contract_all_bindings_and_both_gates(monkeypatch, damage):
    from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
    from tests.test_molmo_grounded_planner import refresh_fixture

    module = api()
    case = module.build_cases("a" * 64)[2]
    state = refresh_fixture(monkeypatch)
    state.request.request_id = case.request_id
    response = PlanningPipeline(planner=state.adapter).process(state.request)
    checksums = [state.request.observation.checksum_sha256, state.captures[0].checksum_sha256]
    events = [
        {"kind": "capture", "phase": "end", "observation_checksum": value, "session_id": "same"}
        for value in checksums
    ]
    events += [
        {
            "kind": "point",
            "phase": "end",
            "status": "POINT",
            "bound": True,
            "observation_checksum": value,
            "actual_generation_delta": 1,
        }
        for value in checksums
        for _ in range(2)
    ]
    events.append(
        {"kind": "paid", "phase": "end", "model": "gpt-6.1-sol", "response_received": True}
    )
    if damage == "binding":
        events[2]["bound"] = False
    elif damage == "frames":
        events[1]["observation_checksum"] = checksums[0]
    elif damage == "final_gate":
        response.attempts[0].draft.observation_evidence.pop("final_plan_admission")
    elif damage == "paid":
        events.pop()
    elif damage == "query_count":
        events.pop(2)
    elif damage == "exception":
        events.append({"kind": "runtime_error"})
    result = module.classify_case(case, response, events)
    assert result["passed"] is (damage is None)
    if damage is None:
        assert result["verdict"] == "PASS_PLANNED"
