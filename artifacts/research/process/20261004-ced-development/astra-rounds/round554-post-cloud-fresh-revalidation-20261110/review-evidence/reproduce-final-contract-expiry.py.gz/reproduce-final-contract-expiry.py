from datetime import timedelta
import json
import pytest
from tests.test_molmo_grounded_planner import refresh_fixture
import cloud_edge_robot_arm.cloud.planning.pipeline as module
with pytest.MonkeyPatch.context() as mp:
    state = refresh_fixture(mp)
    original = module.build_task_contract
    def delayed(*args, **kwargs):
        result = original(*args, **kwargs)
        state.clock += timedelta(seconds=6)
        return result
    mp.setattr(module, 'build_task_contract', delayed)
    response = module.PlanningPipeline(planner=state.adapter).process(state.request)
    evidence = response.attempts[0].draft.observation_evidence
    print(json.dumps({'scope':'CPU_REVIEW_ONLY','outcome':response.outcome,'contract_present':response.contract is not None,'validation_passed':response.validation.passed,'fresh_age_at_return_s':(state.clock-state.captures[0].captured_at).total_seconds(),'refresh_status':evidence['post_cloud_revalidation']['status'],'cloud_calls':len(state.calls),'queries':len(state.queries),'captures':len(state.captures)}))
