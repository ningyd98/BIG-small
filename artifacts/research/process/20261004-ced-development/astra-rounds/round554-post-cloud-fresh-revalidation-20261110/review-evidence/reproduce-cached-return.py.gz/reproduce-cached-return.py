from datetime import timedelta
import json
import pytest
from tests.test_molmo_grounded_planner import refresh_fixture
from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
for variant in ['expired', 'settings_changed']:
    with pytest.MonkeyPatch.context() as mp:
        state = refresh_fixture(mp)
        pipeline = PlanningPipeline(planner=state.adapter)
        first = pipeline.process(state.request)
        if variant == 'expired':
            state.clock += timedelta(seconds=6)
        else:
            state.cloud.timeout_s = 31
        second = pipeline.process(state.request)
        print(json.dumps({'scope':'CPU_REVIEW_ONLY','variant':variant,'same_response_object':second is first,'outcome':second.outcome,'contract_present':second.contract is not None,'fresh_age_at_return_s':(state.clock-state.captures[0].captured_at).total_seconds(),'cloud_calls':len(state.calls),'queries':len(state.queries),'captures':len(state.captures)}))
