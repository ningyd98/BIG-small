import sys,json,hashlib,importlib
from pathlib import Path
original=Path('/home/ningyd/文档/ChatGPT/BIGsmall')
worktree=Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall')
before=list(sys.path)
app=original/'.venv/lib/python3.12/site-packages'
assert app.is_dir()
sys.path.append(str(app))
sys.path.insert(0,str(worktree));sys.path.insert(0,str(worktree/'src'))
modules={}
for name in ['torch','transformers','numpy','cv2','pydantic','cryptography','cloud_edge_robot_arm.vision.molmo_pointing','cloud_edge_robot_arm.vision.grounded_planner','scripts.probe_molmo_grounded_planner']:
 m=importlib.import_module(name); f=Path(m.__file__)
 modules[name]={'version':getattr(m,'__version__',None),'file':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
import torch,transformers,numpy as np,cv2
assert torch.__version__=='2.6.0+cu124'
assert transformers.__version__=='4.57.1'
assert Path(torch.__file__)==original/'.venv-vlm/lib/python3.12/site-packages/torch/__init__.py'
assert Path(transformers.__file__)==original/'artifacts/research/process/20261004-t7-parallel-local-models-physics/molmo/.venv/lib/python3.12/site-packages/transformers/__init__.py'
from transformers import AutoProcessor, AutoModelForImageTextToText
rgb=np.zeros((4,4,3),dtype=np.uint8);rgb[1:3,1:3]=255
gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
count,labels,stats,centroids=cv2.connectedComponentsWithStats((gray>0).astype(np.uint8),connectivity=8)
assert count==2 and stats[1,cv2.CC_STAT_AREA]==4
assert np.array_equal(torch.from_numpy(gray).numpy(),gray)
assert not torch.cuda.is_initialized()
print(json.dumps({'status':'IMPORT_AND_CPU_ABI_PASS','interpreter':sys.executable,'original_sys_path':before,'effective_sys_path':sys.path,'modules':modules,'checks':['cv2.cvtColor uint8 ndarray','cv2.connectedComponentsWithStats area4','torch.from_numpy CPU roundtrip','AutoProcessor and AutoModelForImageTextToText imports','all integration modules imported'],'numpy_abi_error':False,'cuda_initialized':torch.cuda.is_initialized(),'model_loads':0,'generation_calls':0,'network_calls':0,'paid_calls':0,'hardware_dispatch':False},ensure_ascii=False,indent=2))
