"""显式诊断 Molmo/OpenCV/云规划组合；默认空运行，始终禁止硬件派发。"""

from __future__ import annotations

import argparse
import base64
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
from collections.abc import Iterator
from contextlib import ExitStack, contextmanager
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if __package__ in {None, ""}:
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "src"))

from cloud_edge_robot_arm.cloud.planning.models import InitialPlanningRequest
from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
from cloud_edge_robot_arm.vision.grounded_planner import (
    GroundingTaskDescriptor,
    MolmoGroundedPlannerAdapter,
    build_molmo_grounded_planner,
)
from cloud_edge_robot_arm.vision.model_resolver import ModelConfigSnapshot
from cloud_edge_robot_arm.vision.molmo_pointing import (
    BoundPointResult,
    MolmoPointProvider,
    parse_native_point,
)
from cloud_edge_robot_arm.vision.planner import RGBDModelUnavailable, RGBDPlannerAdapter
from cloud_edge_robot_arm.vision.role_models import configuration_hash


def _read(path: Path, limit: int = 5_000_000) -> Any:
    if path.stat().st_size > limit:
        raise ValueError("input exceeds diagnostic limit")
    return json.loads(path.read_bytes())


def _write(path: Path, value: object) -> None:
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


@contextmanager
def _admit_resources(model_directory: Path, lock_path: Path | None) -> Iterator[dict[str, Any]]:
    lock_path = lock_path or (
        model_directory.resolve().parents[2]
        / "zdtaichu5-9b-fp8-round473/research/.r468-r469-gpu.lock"
    )
    if not lock_path.is_file():
        raise ValueError("existing shared GPU lock is required")
    with lock_path.open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        apps = subprocess.check_output(
            ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True
        ).strip()
        free = int(
            subprocess.check_output(
                ["nvidia-smi", "--query-gpu=memory.free", "--format=csv,noheader,nounits"],
                text=True,
            ).strip()
        )
        ram = (
            int(
                next(
                    row.split()[1]
                    for row in Path("/proc/meminfo").read_text().splitlines()
                    if row.startswith("MemAvailable:")
                )
            )
            * 1024
        )
        disk = shutil.disk_usage(model_directory).free
        if apps or free < 12000 or ram < 8 * 1024**3 or disk < 60 * 1024**3:
            raise RuntimeError("local resource admission failed")
        yield {
            "gpu_free_MiB": free,
            "ram_available_bytes": ram,
            "disk_free_bytes": disk,
            "foreign_compute_apps": False,
            "lock_path": str(lock_path),
        }


class _ReplayPoints:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self.rows = {}
        for row in rows:
            key = (row["observation_checksum"], row["query_sha256"])
            if key in self.rows:
                raise ValueError("duplicate replay point binding")
            self.rows[key] = row
        self.calls = 0

    def point(self, observation: Any, phrase: str) -> BoundPointResult:
        query = hashlib.sha256(phrase.encode()).hexdigest()
        row = self.rows.get((observation.checksum_sha256, query))
        if row is None or row["rgb_sha256"] != observation.evidence()["rgb_sha256"]:
            raise RuntimeError("replay point binding mismatch")
        self.calls += 1
        return BoundPointResult(
            parse_native_point(row["raw_text"]),
            observation.checksum_sha256,
            row["rgb_sha256"],
            query,
            {"evidence_scope": "REPLAY"},
        )


class _UnstartedPoints:
    def point(self, observation: Any, phrase: str) -> BoundPointResult:
        raise RuntimeError("native provider not started")


class _DiagnosticCloud(RGBDPlannerAdapter):
    def __init__(self, content: str | None = None) -> None:
        snapshot = ModelConfigSnapshot(
            provider="openai_compatible",
            model="not-invoked",
            endpoint="http://127.0.0.1:11434",
            weight_digest=None,
            quantization=None,
            image_size=(320, 240),
            generation_parameters={"temperature": 0, "num_predict": 512},
            timeout_s=30,
            grasp_profile="mujoco_upright_box_v2",
        )
        super().__init__(
            base_url=snapshot.endpoint,
            provider=snapshot.provider,
            model=snapshot.model,
            model_snapshot=snapshot,
            allow_paid=False,
        )
        self.content = content
        self.fixture_calls = 0

    def _request_visual(self, messages: Any, decision_schema: Any) -> dict[str, Any]:
        if self.content is None:
            raise RGBDModelUnavailable("real cloud deliberately not invoked")
        self.fixture_calls += 1
        return {"choices": [{"message": {"content": self.content}}]}


def _selected_cloud(args: argparse.Namespace, task: GroundingTaskDescriptor) -> Any:
    from cloud_edge_robot_arm.model_control.secret_store import create_secret_store
    from cloud_edge_robot_arm.model_control.service import ModelControlService
    from cloud_edge_robot_arm.model_control.sqlite_repository import SQLiteModelProfileRepository

    if not args.profile_id or not args.model_store or not args.model_store.is_file():
        raise ValueError("paid mode requires an existing explicit model store and profile")
    service = ModelControlService(
        repository=SQLiteModelProfileRepository(args.model_store),
        secret_store=create_secret_store(args.model_store),
    )
    if not service.secret_store.has_secret(args.profile_id):
        raise ValueError("selected profile has no existing saved secret")
    return build_molmo_grounded_planner(
        service=service,
        profile_id=args.profile_id,
        point_provider=_UnstartedPoints(),
        task=task,
        grasp_profile="mujoco_upright_box_v2",
        allow_paid=True,
    )


def _fresh_capture() -> Any:
    from cloud_edge_robot_arm.vision.capture import capture_simulated_observation

    return capture_simulated_observation()


def main(argv: list[str] | None = None) -> int:
    """执行可审计诊断；--allow-paid 只能在另行授权的实际云端验证中使用。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, action="append", required=True)
    parser.add_argument("--task-descriptor", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("dry-run", "replay", "native"), default="dry-run")
    parser.add_argument("--profile-id")
    parser.add_argument("--model-store", type=Path)
    parser.add_argument("--model-directory", type=Path)
    parser.add_argument("--asset-manifest", type=Path)
    parser.add_argument("--replay-points", type=Path)
    parser.add_argument("--replay-cloud", type=Path)
    parser.add_argument("--generation-limit", type=int, default=8)
    parser.add_argument("--gpu-lock", type=Path)
    parser.add_argument("--capture-fresh", action="store_true")
    parser.add_argument("--allow-paid", action="store_true")
    args = parser.parse_args(argv)
    report: dict[str, Any] = {
        "status": "NOT_STARTED",
        "execution_mode": args.mode.upper(),
        "model_loads_started": 0,
        "generation_calls_started": 0,
        "generation_calls_completed": 0,
        "paid_cloud_calls_started": 0,
        "api_fixture_calls": 0,
        "hardware_dispatch": False,
        "real_cloud_status": "NOT_PERFORMED",
        "physical_status": "NOT_PERFORMED",
        "formal_research_status": "NOT_PERFORMED",
        "attempts": [],
    }
    provider = None
    output_created = False
    paid_starts = []
    try:
        if len(args.request) != len(args.task_descriptor) or not 1 <= len(args.request) <= 4:
            raise ValueError("provide 1..4 matching request/descriptor pairs")
        pairs = []
        for request_path, task_path in zip(args.request, args.task_descriptor, strict=True):
            request = InitialPlanningRequest.model_validate(_read(request_path))
            task = GroundingTaskDescriptor.model_validate(_read(task_path, 10000))
            if request.observation is None or request.user_instruction != task.instruction:
                raise ValueError("request/descriptor binding mismatch")
            pairs.append((request, task))
        if not 1 <= args.generation_limit <= 8 or 2 * len(pairs) > args.generation_limit:
            raise ValueError("native generation budget must cover at most8 bounded starts")
        if args.allow_paid and args.mode != "native":
            raise ValueError("paid flag is only valid for explicitly authorized native mode")
        if args.capture_fresh and args.mode != "native":
            raise ValueError("fresh sensor acquisition requires native mode")
        if args.mode == "native" and (
            not args.model_directory
            or not args.model_directory.is_dir()
            or not args.asset_manifest
            or not args.asset_manifest.is_file()
        ):
            raise ValueError("native mode requires existing local assets")
        replay_cloud = None
        if args.mode == "replay":
            if not args.replay_points or not args.replay_cloud or len(pairs) != 1:
                raise ValueError("replay requires one explicitly bound fixture pair")
            provider = _ReplayPoints(_read(args.replay_points))
            replay_cloud = _read(args.replay_cloud)
            request, task = pairs[0]
            if replay_cloud[
                "observation_checksum"
            ] != request.observation.checksum_sha256 or replay_cloud[
                "task_descriptor_sha256"
            ] != configuration_hash(task.model_dump()):
                raise ValueError("replay cloud binding mismatch")
        adapters = [_selected_cloud(args, task) for _, task in pairs] if args.allow_paid else []
        args.output.mkdir(parents=True, exist_ok=False)
        output_created = True
        if args.mode != "dry-run":
            with ExitStack() as stack:
                if args.mode == "native":
                    report["resource_admission"] = stack.enter_context(
                        _admit_resources(args.model_directory, args.gpu_lock)
                    )
                    cache = args.output / "runtime-cache"
                    cache.mkdir()
                    settings = {
                        "HF_HUB_OFFLINE": "1",
                        "TRANSFORMERS_OFFLINE": "1",
                        "HF_HOME": str(cache / "hf"),
                        "HF_MODULES_CACHE": str(cache / "modules"),
                    }
                    old = {key: os.environ.get(key) for key in settings}

                    def restore_environment() -> None:
                        for key, value in old.items():
                            if value is None:
                                os.environ.pop(key, None)
                            else:
                                os.environ[key] = value

                    stack.callback(restore_environment)
                    os.environ.update(settings)
                    provider = MolmoPointProvider(
                        model_directory=args.model_directory,
                        asset_manifest=args.asset_manifest,
                        raw_directory=args.output / "raw/native",
                        generation_limit=args.generation_limit,
                    )
                for index, (request, task) in enumerate(pairs, 1):
                    if args.capture_fresh:
                        observation = _fresh_capture()
                        request = request.model_copy(update={"observation": observation})
                        folder = args.output / "raw" / f"capture-{index:02}"
                        folder.mkdir(parents=True)
                        _write(folder / "request.json", request.model_dump(mode="json"))
                        (folder / "rgb.png").write_bytes(
                            base64.b64decode(observation.rgb_png_base64)
                        )
                        (folder / "depth.f32").write_bytes(
                            base64.b64decode(observation.depth_float32_base64)
                        )
                    if adapters:
                        adapter = adapters[index - 1]
                        adapter.point_provider = provider

                        def observe(phase: str, path: str, data: bytes) -> None:
                            if phase == "REQUEST":
                                paid_starts.append(hashlib.sha256(data).hexdigest())

                        adapter.cloud.raw_transport_observer = observe
                        cloud = adapter.cloud
                    else:
                        content = replay_cloud["content"] if replay_cloud else None
                        cloud = _DiagnosticCloud(content)
                        adapter = MolmoGroundedPlannerAdapter(
                            point_provider=provider, cloud=cloud, task=task
                        )
                    result = PlanningPipeline(planner=adapter).process(request)
                    draft = result.attempts[0].draft if result.attempts else None
                    evidence = draft.observation_evidence if draft else {}
                    ready = "opencv_initial_geometry" in evidence
                    report["attempts"].append(
                        {
                            "request_id": request.request_id,
                            "observation_checksum": request.observation.checksum_sha256,
                            "pipeline_outcome": result.outcome.value,
                            "local_geometry_status": "READY" if ready else "NOT_READY",
                            "parse_error": draft.parse_error if draft else None,
                            "reason": result.reason,
                            "evidence": evidence,
                        }
                    )
                    report["api_fixture_calls"] += getattr(cloud, "fixture_calls", 0)
                report["status"] = "COMPLETED"
        if args.mode == "native":
            report["model_loads_started"] = getattr(provider, "model_loads_started", 0)
            report["generation_calls_started"] = getattr(provider, "generation_calls_started", 0)
            report["generation_calls_completed"] = getattr(
                provider, "generation_calls_completed", 0
            )
        report["paid_cloud_calls_started"] = len(paid_starts)
        if paid_starts:
            report["real_cloud_status"] = "ATTEMPTED"
        if args.mode == "replay":
            ok = all(row["pipeline_outcome"] == "PLANNED" for row in report["attempts"])
        else:
            ok = args.mode == "dry-run" or all(
                row["local_geometry_status"] == "READY" for row in report["attempts"]
            )
        report["diagnostic_passed"] = ok
        raw = args.output / "raw"
        if raw.exists():
            rows = []
            for path in sorted(raw.rglob("*")):
                if path.is_file():
                    with path.open("rb") as stream:
                        digest = hashlib.file_digest(stream, "sha256").hexdigest()
                    rows.append(
                        {
                            "path": str(path.relative_to(args.output)),
                            "bytes": path.stat().st_size,
                            "sha256": digest,
                        }
                    )
            _write(args.output / "raw-manifest.local.json", {"files": rows})
        _write(args.output / "report.json", report)
        print(
            json.dumps(
                {
                    key: report[key]
                    for key in (
                        "status",
                        "execution_mode",
                        "diagnostic_passed",
                        "model_loads_started",
                        "generation_calls_started",
                        "paid_cloud_calls_started",
                    )
                }
            )
        )
        return 0 if ok else 2
    except Exception as exc:
        report.update(
            status="FAILED",
            error_type=type(exc).__name__,
            diagnostic_passed=False,
            model_loads_started=getattr(provider, "model_loads_started", 0),
            generation_calls_started=getattr(provider, "generation_calls_started", 0),
            generation_calls_completed=getattr(provider, "generation_calls_completed", 0),
            paid_cloud_calls_started=len(paid_starts),
        )
        raw = args.output / "raw/native"
        if provider is None and raw.exists():
            report["model_loads_started"] = int((raw / "load-started.json").exists())
        if output_created:
            _write(args.output / "report.json", report)
        print(json.dumps({"status": "FAILED", "error_type": type(exc).__name__}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
