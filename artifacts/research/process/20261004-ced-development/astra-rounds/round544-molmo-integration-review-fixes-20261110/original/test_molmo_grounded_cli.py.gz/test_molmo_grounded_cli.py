"""诊断入口必须明确区分空运行、回放与真实推理，并保留失败计数。"""

from __future__ import annotations

import hashlib
import json
from contextlib import contextmanager
from pathlib import Path

from tests.test_molmo_grounded_planner import SKILLS, FixturePoints, request_scene


def inputs(tmp_path):
    request = request_scene()
    task = {
        "instruction": request.user_instruction,
        "target_phrase": "red block",
        "destination_phrase": "green region",
        "target_label": "red block",
    }
    request_path = tmp_path / "request.json"
    request_path.write_text(request.model_dump_json())
    task_path = tmp_path / "task.json"
    task_path.write_text(json.dumps(task))
    return request, task, request_path, task_path


def args(tmp_path, request_path, task_path):
    return [
        "--request",
        str(request_path),
        "--task-descriptor",
        str(task_path),
        "--output",
        str(tmp_path / "out"),
    ]


def test_cli_dry_run_has_zero_calls(tmp_path):
    from scripts.probe_molmo_grounded_planner import main

    _, _, request_path, task_path = inputs(tmp_path)
    assert main(args(tmp_path, request_path, task_path)) == 0
    report = json.loads((tmp_path / "out/report.json").read_text())
    assert report["status"] == "NOT_STARTED"
    assert report["model_loads_started"] == report["generation_calls_started"] == 0
    assert report["paid_cloud_calls_started"] == 0 and report["hardware_dispatch"] is False


def replay_files(tmp_path, request, task):
    task_hash = hashlib.sha256(
        json.dumps(task, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    ).hexdigest()
    points = []
    for phrase, coords in [
        ("visible top center of red block", "150 410"),
        ("interior of green region", "650 425"),
    ]:
        points.append(
            {
                "observation_checksum": request.observation.checksum_sha256,
                "rgb_sha256": request.observation.evidence()["rgb_sha256"],
                "query_sha256": hashlib.sha256(phrase.encode()).hexdigest(),
                "raw_text": f'<points coords="1 1 {coords}">support</points>',
            }
        )
    p = tmp_path / "points.json"
    p.write_text(json.dumps(points))
    c = tmp_path / "cloud.json"
    c.write_text(
        json.dumps(
            {
                "observation_checksum": request.observation.checksum_sha256,
                "task_descriptor_sha256": task_hash,
                "content": json.dumps({"skills": SKILLS}),
            }
        )
    )
    return p, c


def test_cli_replay_is_labelled_and_no_network(tmp_path, monkeypatch):
    import socket

    from scripts.probe_molmo_grounded_planner import main

    request, task, r, t = inputs(tmp_path)
    p, c = replay_files(tmp_path, request, task)

    def no_network(*a, **k):
        raise AssertionError("replay attempted network")

    monkeypatch.setattr(socket, "socket", no_network)
    assert (
        main(
            args(tmp_path, r, t)
            + ["--mode", "replay", "--replay-points", str(p), "--replay-cloud", str(c)]
        )
        == 0
    )
    report = json.loads((tmp_path / "out/report.json").read_text())
    assert report["execution_mode"] == "REPLAY"
    assert report["attempts"][0]["pipeline_outcome"] == "PLANNED"
    assert report["generation_calls_started"] == report["paid_cloud_calls_started"] == 0
    assert report["api_fixture_calls"] == 1


def test_cli_replay_binding_mismatch_is_rejected(tmp_path):
    from scripts.probe_molmo_grounded_planner import main

    request, task, r, t = inputs(tmp_path)
    p, c = replay_files(tmp_path, request, task)
    rows = json.loads(p.read_text())
    rows[0]["query_sha256"] = "0" * 64
    p.write_text(json.dumps(rows))
    assert (
        main(
            args(tmp_path, r, t)
            + ["--mode", "replay", "--replay-points", str(p), "--replay-cloud", str(c)]
        )
        != 0
    )


def test_cli_preexisting_output_is_untouched(tmp_path):
    from scripts.probe_molmo_grounded_planner import main

    _, _, r, t = inputs(tmp_path)
    out = tmp_path / "out"
    out.mkdir()
    (out / "keep").write_text("original")
    assert main(args(tmp_path, r, t)) != 0
    assert (out / "keep").read_text() == "original"
    assert sorted(p.name for p in out.iterdir()) == ["keep"]


@contextmanager
def admitted(*args, **kwargs):
    yield {"evidence_scope": "CPU_RESOURCE_FIXTURE"}


class NativeFixture(FixturePoints):
    def __init__(self, **kwargs):
        super().__init__()
        self.model_loads_started = 1
        self.generation_calls_started = 0
        self.generation_calls_completed = 0
        self.raw = Path(kwargs["raw_directory"])
        self.raw.mkdir(parents=True)

    def point(self, observation, phrase):
        self.generation_calls_started += 1
        value = super().point(observation, phrase)
        self.generation_calls_completed += 1
        return value


def test_cli_native_no_paid_default(tmp_path, monkeypatch):
    import scripts.probe_molmo_grounded_planner as cli

    _, _, r, t = inputs(tmp_path)
    monkeypatch.setattr(cli, "MolmoPointProvider", NativeFixture)
    monkeypatch.setattr(cli, "_admit_resources", admitted)
    model = tmp_path / "model"
    model.mkdir()
    manifest = tmp_path / "manifest"
    manifest.write_text("{}")
    assert (
        cli.main(
            args(tmp_path, r, t)
            + [
                "--mode",
                "native",
                "--model-directory",
                str(model),
                "--asset-manifest",
                str(manifest),
            ]
        )
        == 0
    )
    report = json.loads((tmp_path / "out/report.json").read_text())
    assert report["model_loads_started"] == 1 and report["generation_calls_started"] == 2
    assert report["paid_cloud_calls_started"] == 0 and report["api_fixture_calls"] == 0
    assert report["attempts"][0]["local_geometry_status"] == "READY"
    assert report["real_cloud_status"] == "NOT_PERFORMED"


def test_cli_invalid_config_precedes_load(tmp_path, monkeypatch):
    import scripts.probe_molmo_grounded_planner as cli

    _, task, r, t = inputs(tmp_path)
    task["instruction"] = "different task"
    t.write_text(json.dumps(task))

    def forbidden(**kwargs):
        raise AssertionError("invalid config loaded model")

    monkeypatch.setattr(cli, "MolmoPointProvider", forbidden)
    assert cli.main(args(tmp_path, r, t) + ["--mode", "native"]) != 0


def test_cli_accounting_keeps_failed_attempt(tmp_path, monkeypatch):
    import scripts.probe_molmo_grounded_planner as cli

    _, _, r, t = inputs(tmp_path)

    class FailingNative(NativeFixture):
        def point(self, observation, phrase):
            self.generation_calls_started += 1
            (self.raw / "failure.json").write_text('{"generation_calls_started":1}')
            raise RuntimeError("CPU_FIXTURE_FAILURE")

    monkeypatch.setattr(cli, "MolmoPointProvider", FailingNative)
    monkeypatch.setattr(cli, "_admit_resources", admitted)
    model = tmp_path / "model"
    model.mkdir()
    manifest = tmp_path / "manifest"
    manifest.write_text("{}")
    assert (
        cli.main(
            args(tmp_path, r, t)
            + [
                "--mode",
                "native",
                "--model-directory",
                str(model),
                "--asset-manifest",
                str(manifest),
            ]
        )
        != 0
    )
    report = json.loads((tmp_path / "out/report.json").read_text())
    assert report["generation_calls_started"] == 1 and report["generation_calls_completed"] == 0
    assert (tmp_path / "out/raw/native/failure.json").exists()
