"""固定七案的开发接口验证；原始证据本地保存，不派发硬件。"""

# ruff: noqa: E402
from __future__ import annotations

import argparse
import copy
import fcntl
import hashlib
import json
import os
import sys
import uuid
from collections import Counter
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from time import monotonic
from typing import Any, Literal

ROOT = Path(__file__).resolve().parents[1]
if __package__ in {None, ""}:
    sys.path[:0] = [str(ROOT), str(ROOT / "src")]

from cloud_edge_robot_arm.cloud.planning.models import (
    InitialPlanningRequest,
    InitialPlanningResponse,
    RobotCapabilities,
    SceneSummary,
)
from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
from cloud_edge_robot_arm.datasets.rgbd.models import SceneSpec
from cloud_edge_robot_arm.datasets.rgbd.scene_sampler import COLORS
from cloud_edge_robot_arm.simulation.config import SimulatorConfig
from cloud_edge_robot_arm.vision.capture import MuJoCoCaptureSession
from cloud_edge_robot_arm.vision.grounded_planner import (
    GroundingTaskDescriptor,
    build_molmo_grounded_planner,
)
from cloud_edge_robot_arm.vision.molmo_pointing import MolmoPointProvider, PointProvider
from cloud_edge_robot_arm.vision.role_models import cloud_request_settings, configuration_hash
from scripts.probe_molmo_grounded_planner import _admit_resources, _save_capture

ROUND = ROOT / (
    "artifacts/research/process/20261004-ced-development/astra-rounds/"
    "round558-multiscene-grounded-interface-20261110"
)
GROUPS = {"G1": ("N01", "N02", "P01"), "G2": ("N03", "P02"), "G3": ("N04", "P03")}
CAPS = {"G1": 8, "G2": 6, "G3": 6}
SETTINGS_SHA = "eb31dd5eb394646e1a09a0116c7d8d58c954a8c200f2443d12b5ce3ef972362d"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    ).encode()


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(_canonical(value))
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _stamp() -> dict[str, Any]:
    return {"utc": datetime.now(UTC).isoformat(), "monotonic_s": monotonic()}


@dataclass(frozen=True)
class CaseSpec:
    case_id: str
    group_id: str
    expected: Literal["positive", "negative"]
    scene: SceneSpec
    task: GroundingTaskDescriptor
    request_id: str
    point_cap: int
    paid_cap: int

    def payload(self) -> dict[str, Any]:
        return {
            **{
                name: getattr(self, name)
                for name in (
                    "case_id",
                    "group_id",
                    "expected",
                    "request_id",
                    "point_cap",
                    "paid_cap",
                )
            },
            "scene": self.scene.model_dump(mode="json"),
            "task": self.task.model_dump(mode="json"),
        }

    @classmethod
    def read(cls, value: dict[str, Any]) -> CaseSpec:
        value = dict(value)
        value["scene"] = SceneSpec.model_validate(value["scene"])
        value["task"] = GroundingTaskDescriptor.model_validate(value["task"])
        return cls(**value)


def build_cases(asset_sha256: str) -> tuple[CaseSpec, ...]:
    """在渲染和模型访问前固定所有场景及显式任务。"""
    if len(asset_sha256) != 64 or any(c not in "0123456789abcdef" for c in asset_sha256):
        raise ValueError("invalid asset identity")

    def box(color: str, position: list[float], size=None):
        return {
            "position": position,
            "half_size": size or [0.035, 0.035, 0.035],
            "rgba": COLORS[color].copy(),
            "color_name": color,
            "mass_kg": 0.08,
            "friction": 1.0,
        }

    def scene(color, target, destination):
        return {
            "target": box(color, target),
            "distractors": [],
            "destination": {
                "position": destination,
                "half_size": [0.08, 0.08, 0.002],
                "rgba": [0.1, 0.6, 0.2, 1],
            },
            "camera": {"position": [0.35, 0, 1.4], "quaternion": [1, 0, 0, 0], "fovy": 50},
            "light_intensity": 0.9,
            "depth_noise_m": 0.0,
            "invalid_depth_fraction": 0.0,
        }

    nominal = scene("red", [0.45, 0, 0.035], [0.20, 0.25, 0.002])
    shifted = scene("red", [0.36, -0.16, 0.035], [0.18, 0.18, 0.002])
    blue = scene("blue", [0.52, 0.12, 0.035], [0.20, 0.25, 0.002])
    parameters = {
        "P01": nominal,
        "P02": shifted,
        "P03": blue,
        "N01": copy.deepcopy(nominal),
        "N02": copy.deepcopy(nominal),
        "N03": copy.deepcopy(shifted),
        "N04": copy.deepcopy(blue),
    }
    parameters["N02"]["distractors"] = [box("red", [0.62, -0.12, 0.035])]
    parameters["N03"]["destination"]["rgba"] = [0.5, 0.5, 0.5, 1]
    parameters["N04"]["distractors"] = [box("yellow", [0.55, 0.145, 0.12], [0.025, 0.025, 0.045])]
    colors = {
        "P01": "red",
        "P02": "red",
        "P03": "blue",
        "N01": "blue",
        "N02": "red",
        "N03": "red",
        "N04": "blue",
    }
    result = []
    for group, ids in GROUPS.items():
        for name in ids:
            color = colors[name]
            task = GroundingTaskDescriptor(
                instruction=f"Move the {color} block to the green region.",
                target_phrase=f"{color} block",
                destination_phrase="green region",
                target_label=f"{color} block",
            )
            positive = name.startswith("P")
            result.append(
                CaseSpec(
                    name,
                    group,
                    "positive" if positive else "negative",
                    SceneSpec.from_parameters(parameters[name], asset_sha256, 0),
                    task,
                    f"r558-{name.lower()}",
                    4 if positive else 2,
                    int(positive),
                )
            )
    return tuple(result)


def preregister(
    output: Path, cases: tuple[CaseSpec, ...], source_hashes: dict[str, str]
) -> dict[str, Any]:
    """独占登记整个分母，目录及登记均不可覆盖。"""
    output.mkdir(parents=True, exist_ok=False)
    rows = [case.payload() for case in cases]
    expected = [name for ids in GROUPS.values() for name in ids]
    if [row["case_id"] for row in rows] != expected:
        raise ValueError("registry must contain the fixed seven ordered cases")
    registry = {
        "schema": "molmo.interface.r558.v1",
        "raw_root": str(output.resolve()),
        "root_id": uuid.uuid4().hex,
        "cases": rows,
        "groups": {g: {"cases": list(ids), "point_cap": CAPS[g]} for g, ids in GROUPS.items()},
        "source_hashes": source_hashes,
        "prior": {"loads": 4, "generations": 10, "paid": 2},
        "additional_max": {"loads": 3, "generations": 20, "paid": 3},
        "retries": 0,
        "hardware_dispatch": False,
        "physical_formal": "NOT_RUN",
        "sensor_noise": "existing apply_scene clean raw path, 0m; no offline perturbation",
    }
    _write(output / "registry.json", registry)
    _write(output / "registry.sha256", {"sha256": _sha(output / "registry.json")})
    for directory in ["claims", "reservations", "events"]:
        (output / directory).mkdir()
    (output / "ledger.lock").touch(exist_ok=False)
    (output / "group.lock").touch(exist_ok=False)
    return registry


class RunLedger:
    """预留先于委托，崩溃和失败占用额度；实际计数另行核对。"""

    def __init__(self, output: Path, registry: dict[str, Any]):
        if (
            registry["raw_root"] != str(output.resolve())
            or _canonical(registry) != (output / "registry.json").read_bytes()
            or _sha(output / "registry.json")
            != json.loads((output / "registry.sha256").read_bytes())["sha256"]
        ):
            raise ValueError("registry/root identity changed")
        self.output, self.registry = output, registry
        self.cases = {row["case_id"]: row for row in registry["cases"]}
        self.fatal = False
        self.group_id = None
        self._group_lock = None

    @contextmanager
    def locked(self):
        with (self.output / "ledger.lock").open("r+") as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)

    def claim(self, group_id: str) -> None:
        if group_id not in GROUPS or self._group_lock is not None:
            raise ValueError("invalid group claim")
        stream = (self.output / "group.lock").open("r+")
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.locked():
                claim = self.output / "claims" / f"group-{group_id}.json"
                if claim.exists():
                    raise ValueError("group already claimed; no restart")
                earlier = list(GROUPS)[: list(GROUPS).index(group_id)]
                if any(
                    not (self.output / "claims" / f"group-{group}.json").exists()
                    for group in earlier
                ):
                    raise ValueError("group order violation")
                _write(claim, {"group_id": group_id, "pid": os.getpid(), **_stamp()})
        except BaseException:
            stream.close()
            raise
        self._group_lock, self.group_id = stream, group_id

    def close(self) -> None:
        if self._group_lock is not None:
            self._group_lock.close()
            self._group_lock = None

    def _case_path(self, case_id, phase):
        return self.output / "claims" / f"case-{case_id}-{phase}.json"

    def begin_case(self, group_id: str, case_id: str) -> None:
        with self.locked():
            if group_id != self.group_id or case_id not in GROUPS[group_id]:
                raise ValueError("case/group mismatch")
            earlier = GROUPS[group_id][: GROUPS[group_id].index(case_id)]
            if any(not self._case_path(name, "end").exists() for name in earlier):
                raise ValueError("case order violation")
            _write(self._case_path(case_id, "start"), _stamp())

    def end_case(self, group_id: str, case_id: str) -> None:
        if group_id != self.group_id or not self._case_path(case_id, "start").exists():
            raise ValueError("case not started")
        _write(self._case_path(case_id, "end"), _stamp())

    def reserve(
        self, kind: Literal["load", "point", "paid"], *, group_id: str, case_id: str | None
    ) -> Path:
        with self.locked():
            if group_id != self.group_id or kind not in {"load", "point", "paid"}:
                raise ValueError("invalid reservation")
            if kind == "load":
                if case_id is not None:
                    raise ValueError("load is group scoped")
                cap, case_cap, total_cap = 1, 1, 3
            else:
                if (
                    case_id not in GROUPS[group_id]
                    or not self._case_path(case_id, "start").exists()
                    or self._case_path(case_id, "end").exists()
                ):
                    raise ValueError("inactive case reservation")
                cap, case_cap, total_cap = (
                    (CAPS[group_id], self.cases[case_id]["point_cap"], 20)
                    if kind == "point"
                    else (1, self.cases[case_id]["paid_cap"], 3)
                )
            rows = [
                json.loads(p.read_bytes())
                for p in (self.output / "reservations").glob(f"{kind}-*.json")
            ]
            if (
                len(rows) >= total_cap
                or sum(row["group_id"] == group_id for row in rows) >= cap
                or sum(row["group_id"] == group_id and row["case_id"] == case_id for row in rows)
                >= case_cap
            ):
                raise ValueError("reservation allocation exhausted")
            path = self.output / "reservations" / f"{kind}-{len(rows) + 1:03}.json"
            try:
                _write(path, {"kind": kind, "group_id": group_id, "case_id": case_id, **_stamp()})
            except OSError:
                self.fatal = True
                raise
            return path

    def record(self, case_id: str, **event) -> None:
        folder = self.output / "events" / case_id
        folder.mkdir(exist_ok=True)
        event = {**_stamp(), **event}
        try:
            _write(folder / f"{len(list(folder.glob('*.json'))) + 1:04}.json", event)
        except OSError:
            self.fatal = True
            raise

    def events_for(self, case_id: str) -> list[dict[str, Any]]:
        return [
            json.loads(path.read_bytes())
            for path in sorted((self.output / "events" / case_id).glob("*.json"))
        ]


def classify_case(
    case: CaseSpec, response: InitialPlanningResponse | None, events: list[dict[str, Any]]
) -> dict[str, Any]:
    """按真实出口和因果事件保守分类；预算阻断不算正确拒绝。"""
    points = [e for e in events if e.get("kind") == "point" and e.get("phase") == "end"]
    captures = [e for e in events if e.get("kind") == "capture" and e.get("phase") == "end"]
    paid = [
        e
        for e in events
        if e.get("kind") == "paid" and e.get("phase") == "end" and e.get("response_received")
    ]
    kinds = {e["kind"] for e in events}
    result = {
        "case_id": case.case_id,
        "group_id": case.group_id,
        "expected": case.expected,
        "verdict": "FAIL_INTERFACE",
        "passed": False,
        "refusal_source": None,
        "point_statuses": [e["status"] for e in points],
        "actual_generations": sum(e.get("actual_generation_delta", 0) for e in points),
        "capture_count": len(captures),
        "paid_responses": len(paid),
        "outcome": response.outcome.value if response else None,
        "reason": response.reason if response else None,
    }
    if case.expected == "negative" and "cloud_entry" in kinds:
        result["verdict"] = "FAIL_CLOUD_GATE_REACHED"
        return result
    if "budget_block" in kinds:
        result["verdict"] = "FAIL_BUDGET_BLOCK"
        return result
    if response is None or kinds & {"runtime_error", "capture_gap", "evidence_error"}:
        result["verdict"] = "ERROR_OR_INCOMPLETE"
        return result
    if response.request_id != case.request_id or any(
        not e.get("bound") or e["status"] not in {"POINT", "ABSENT"} for e in points
    ):
        result["verdict"] = "ERROR_POINT_OR_BINDING"
        return result
    if case.expected == "negative":
        if (
            response.outcome.value != "REQUEST_MORE_OBSERVATION"
            or response.contract is not None
            or paid
        ):
            return result
        if any(e["status"] == "ABSENT" for e in points):
            result.update(
                verdict="PASS_EXPECTED_REJECTION", passed=True, refusal_source="model_absence"
            )
        elif (
            points
            and all(e["status"] == "POINT" for e in points)
            and any(
                e.get("kind") == "stage" and e.get("phase") == "error" and e.get("visual_rejection")
                for e in events
            )
        ):
            result.update(
                verdict="PASS_EXPECTED_REJECTION", passed=True, refusal_source="program_geometry"
            )
        return result
    evidence = response.attempts[-1].draft.observation_evidence if response.attempts else {}
    frame_ids = [e.get("observation_checksum") for e in captures]
    if (
        response.outcome.value == "PLANNED"
        and response.contract is not None
        and response.validation.passed
        and evidence.get("post_cloud_revalidation", {}).get("status") == "PASSED"
        and evidence.get("final_plan_admission", {}).get("status") == "PASSED"
        and len(points) == 4
        and all(e["status"] == "POINT" and e.get("actual_generation_delta") == 1 for e in points)
        and len(captures) == 2
        and len(set(frame_ids)) == 2
        and len({e.get("session_id") for e in captures}) == 1
        and [e.get("observation_checksum") for e in points]
        == [frame_ids[0]] * 2 + [frame_ids[1]] * 2
        and len(paid) == 1
        and paid[0].get("model") == "gpt-6.1-sol"
    ):
        result.update(verdict="PASS_PLANNED", passed=True)
    return result


def summarize(registry: dict[str, Any], results: list[dict[str, Any]]) -> dict[str, Any]:
    """固定3/4/7分母，未知或重复记录使汇总无效。"""
    assigned = registry["cases"]
    counts = Counter(row["case_id"] for row in results)
    ids = {case["case_id"] for case in assigned}
    unknown = sum(row["case_id"] not in ids for row in results)
    duplicates = sum(counts[name] > 1 for name in ids)
    cases = []
    for case in assigned:
        matched = [row for row in results if row["case_id"] == case["case_id"]]
        cases.append(
            matched[0]
            if len(matched) == 1
            else {
                "case_id": case["case_id"],
                "expected": case["expected"],
                "verdict": "NOT_RUN" if not matched else "INVALID_DUPLICATE",
                "passed": False,
            }
        )
    valid = not unknown and not duplicates
    passed = (
        sum(row.get("verdict") in {"PASS_PLANNED", "PASS_EXPECTED_REJECTION"} for row in cases)
        if valid
        else 0
    )
    return {
        "total_cases": 7,
        "positive_cases": 3,
        "negative_cases": 4,
        "cases": cases,
        "unknown_records": unknown,
        "duplicate_cases": duplicates,
        "missing_cases": sum(counts[name] == 0 for name in ids),
        "valid_suite": valid,
        "passed_cases": passed,
        "positive_passed": sum(row.get("verdict") == "PASS_PLANNED" for row in cases)
        if valid
        else 0,
        "negative_passed": sum(row.get("verdict") == "PASS_EXPECTED_REJECTION" for row in cases)
        if valid
        else 0,
        "all_cases_pass": valid and passed == 7 and len(results) == 7,
    }


@contextmanager
def _observe_stages(ledger: RunLedger, case: CaseSpec):
    import cloud_edge_robot_arm.vision.grounded_planner as module

    originals = {}
    for attribute, label in [
        ("associate_target_point", "association"),
        ("ground_observation", "grounding"),
        ("OpenCVTargetTracker", "tracker"),
    ]:
        original = getattr(module, attribute)
        originals[attribute] = original

        def observed(*args, _original=original, _stage=label, **kwargs):
            ledger.record(case.case_id, kind="stage", phase="start", stage=_stage)
            try:
                result = _original(*args, **kwargs)
            except Exception as exc:
                visual = isinstance(exc, ValueError) and not any(
                    word in str(exc).lower()
                    for word in [
                        "calibration",
                        "invalid depth",
                        "finite",
                        "checksum",
                        "time_not_fresh",
                    ]
                )
                ledger.record(
                    case.case_id,
                    kind="stage",
                    phase="error",
                    stage=_stage,
                    error_type=type(exc).__name__,
                    visual_rejection=visual,
                )
                raise
            ledger.record(case.case_id, kind="stage", phase="end", stage=_stage)
            return result

        setattr(module, attribute, observed)
    try:
        yield
    finally:
        for attribute, original in originals.items():
            setattr(module, attribute, original)


def run_case(
    case: CaseSpec,
    *,
    provider: PointProvider,
    service: Any,
    profile_id: str,
    ledger: RunLedger,
    output: Path,
) -> InitialPlanningResponse:
    """每案一次原pipeline调用；返回原对象，事件及原始输入独立保存。"""
    ledger.begin_case(case.group_id, case.case_id)
    folder = output / case.group_id / case.case_id
    folder.mkdir(parents=True, exist_ok=False)
    _write(folder / "task.json", case.task.model_dump(mode="json"))
    _write(folder / "scene-setup.json", case.scene.model_dump(mode="json"))
    captures = []
    request = None
    session_id = uuid.uuid4().hex

    class Points:
        def point(self, observation, phrase):
            try:
                ledger.reserve("point", group_id=case.group_id, case_id=case.case_id)
            except ValueError:
                ledger.record(case.case_id, kind="budget_block", operation="point")
                raise
            ledger.record(
                case.case_id,
                kind="point",
                phase="start",
                observation_checksum=observation.checksum_sha256,
            )
            before = getattr(provider, "generation_calls_started", 0)
            try:
                result = provider.point(observation, phrase)
            except Exception as exc:
                ledger.record(
                    case.case_id,
                    kind="runtime_error",
                    operation="point",
                    error_type=type(exc).__name__,
                )
                raise
            bound = (
                result.observation_checksum == observation.checksum_sha256
                and result.rgb_sha256 == observation.evidence()["rgb_sha256"]
                and result.query_sha256 == hashlib.sha256(phrase.encode()).hexdigest()
            )
            ledger.record(
                case.case_id,
                kind="point",
                phase="end",
                status=result.result.status,
                bound=bound,
                observation_checksum=result.observation_checksum,
                query_sha256=result.query_sha256,
                actual_generation_delta=getattr(provider, "generation_calls_started", 0) - before,
            )
            return result

    try:
        with MuJoCoCaptureSession(SimulatorConfig(render_rgb=True, render_depth=True)) as session:
            session.apply_scene(case.scene)

            def capture():
                if len(captures) >= (2 if case.expected == "positive" else 1):
                    ledger.record(case.case_id, kind="budget_block", operation="capture")
                    raise RuntimeError("capture allocation exhausted")
                ledger.record(case.case_id, kind="capture", phase="start", session_id=session_id)
                observation = session.capture()
                captures.append(observation)
                ledger.record(
                    case.case_id,
                    kind="capture",
                    phase="end",
                    session_id=session_id,
                    observation_checksum=observation.checksum_sha256,
                    captured_at=observation.captured_at.isoformat(),
                    sim_time_s=observation.sim_time_s,
                    rgb_sha256=observation.evidence()["rgb_sha256"],
                )
                if request is not None:
                    _save_capture(folder / "capture-02", request, observation)
                return observation

            initial = capture()
            request = InitialPlanningRequest(
                request_id=case.request_id,
                user_instruction=case.task.instruction,
                observation=initial,
                scene=SceneSummary(scene_version=1, updated_at=initial.captured_at),
                capabilities=RobotCapabilities(
                    supported_skills=[
                        "HOME",
                        "MOVE_ABOVE",
                        "APPROACH",
                        "GRASP",
                        "LIFT",
                        "MOVE_TO_REGION",
                        "PLACE",
                        "RELEASE",
                        "RETREAT",
                    ]
                ),
            )
            _save_capture(folder / "capture-01", request, initial)
            adapter = build_molmo_grounded_planner(
                service=service,
                profile_id=profile_id,
                point_provider=Points(),
                task=case.task,
                grasp_profile="mujoco_upright_box_v2",
                allow_paid=True,
                post_cloud_observation_supplier=capture if case.expected == "positive" else None,
            )
            cloud = adapter.cloud
            original_visual, original_post = cloud._request_visual, cloud._post
            original_observer = cloud.raw_transport_observer
            wire_counts = Counter()

            def wire(phase, path, data):
                wire_counts[phase] += 1
                path_out = folder / "cloud" / f"{phase.lower()}-{wire_counts[phase]:04}.json"
                path_out.parent.mkdir(exist_ok=True)
                with path_out.open("xb") as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())

            def visual(*args, **kwargs):
                ledger.record(case.case_id, kind="cloud_entry")
                if case.expected == "negative":
                    raise RuntimeError("negative cloud entry forbidden")
                return original_visual(*args, **kwargs)

            def post(path, body):
                try:
                    ledger.reserve("paid", group_id=case.group_id, case_id=case.case_id)
                except ValueError:
                    ledger.record(case.case_id, kind="budget_block", operation="paid")
                    raise
                ledger.record(case.case_id, kind="paid", phase="start")
                if path != "/v1/chat/completions" or body.get("model") != "gpt-6.1-sol":
                    raise RuntimeError("selected cloud route drift")
                try:
                    result = original_post(path, body)
                except Exception as exc:
                    ledger.record(
                        case.case_id,
                        kind="runtime_error",
                        operation="paid",
                        error_type=type(exc).__name__,
                    )
                    raise
                ledger.record(
                    case.case_id,
                    kind="paid",
                    phase="end",
                    response_received=True,
                    model=result.get("model"),
                    usage=result.get("usage"),
                    http_numeric_status="NOT_CAPTURED",
                )
                return result

            cloud._request_visual, cloud._post, cloud.raw_transport_observer = visual, post, wire
            try:
                with _observe_stages(ledger, case):
                    ledger.record(case.case_id, kind="pipeline", phase="start")
                    response = PlanningPipeline(planner=adapter).process(request)
                    ledger.record(case.case_id, kind="pipeline", phase="end")
                _write(folder / "pipeline-return.json", response.model_dump(mode="json"))
                return response
            finally:
                cloud._request_visual, cloud._post, cloud.raw_transport_observer = (
                    original_visual,
                    original_post,
                    original_observer,
                )
    except Exception as exc:
        ledger.record(
            case.case_id, kind="runtime_error", operation="case", error_type=type(exc).__name__
        )
        raise
    finally:
        ledger.end_case(case.group_id, case.case_id)


def _profile(model_store, profile_id, task):
    from cloud_edge_robot_arm.model_control.secret_store import create_secret_store
    from cloud_edge_robot_arm.model_control.service import ModelControlService
    from cloud_edge_robot_arm.model_control.sqlite_repository import SQLiteModelProfileRepository

    if not model_store.is_file():
        raise ValueError("existing model store required")
    service = ModelControlService(
        repository=SQLiteModelProfileRepository(model_store),
        secret_store=create_secret_store(model_store),
    )
    if not service.secret_store.has_secret(profile_id):
        raise ValueError("existing saved secret required")
    adapter = build_molmo_grounded_planner(
        service=service,
        profile_id=profile_id,
        point_provider=object(),
        task=task,
        grasp_profile="mujoco_upright_box_v2",
        allow_paid=True,
    )
    settings = cloud_request_settings(adapter.cloud)
    if configuration_hash(settings) != SETTINGS_SHA:
        raise ValueError("selected Sol settings drift")
    return service, {
        "settings_hash": SETTINGS_SHA,
        "secret_present": True,
        "role": adapter.cloud.role_snapshot.evidence(),
    }


def _check_sources(registry):
    required = json.loads((ROUND / "plan.json").read_bytes())["inputs"]
    for row in required:
        relative = str(Path(row["path"]).relative_to(ROOT))
        if registry["source_hashes"].get(relative) != row["sha256"]:
            raise ValueError("frozen source missing or changed")
    for name, digest in registry["source_hashes"].items():
        path = (ROOT / name).resolve(strict=True)
        if not path.is_relative_to(ROOT) or _sha(path) != digest:
            raise ValueError("source identity drift")


def _manifest(folder):
    rows = [
        {"path": str(path.relative_to(folder)), "bytes": path.stat().st_size, "sha256": _sha(path)}
        for path in sorted(folder.rglob("*"))
        if path.is_file() and "runtime-cache" not in path.relative_to(folder).parts
    ]
    _write(folder / "raw-manifest.local.json", {"files": rows, "excluded": ["runtime-cache"]})


def run_group(
    group_id: str,
    *,
    registry: Path,
    output: Path,
    model_directory: Path,
    asset_manifest: Path,
    model_store: Path,
    profile_id: str,
    gpu_lock: Path,
    allow_paid: bool,
) -> dict[str, Any]:
    """一个独立主线程进程处理一组，无恢复或重试选项。"""
    if not allow_paid or group_id not in GROUPS:
        raise ValueError("explicit bounded paid mode and registered group required")
    registered = json.loads(registry.read_bytes())
    if registry.read_bytes() != (output / "registry.json").read_bytes():
        raise ValueError("external registry drift")
    _check_sources(registered)
    ledger = RunLedger(output, registered)
    ledger.claim(group_id)
    group = output / group_id
    group.mkdir(exist_ok=False)
    provider = None
    results = []
    error = None
    try:
        cases = [CaseSpec.read(row) for row in registered["cases"] if row["group_id"] == group_id]
        if tuple(c.case_id for c in cases) != GROUPS[group_id]:
            raise ValueError("registered group changed")
        service, profile = _profile(model_store, profile_id, cases[0].task)
        _write(group / "profile-preflight.json", profile)
        with _admit_resources(model_directory, gpu_lock) as resources:
            _write(group / "resources.json", resources)
            cache = group / "runtime-cache"
            os.environ.update(
                HF_HUB_OFFLINE="1",
                TRANSFORMERS_OFFLINE="1",
                HF_HOME=str(cache / "hf"),
                HF_MODULES_CACHE=str(cache / "modules"),
                PYTHONDONTWRITEBYTECODE="1",
            )
            ledger.reserve("load", group_id=group_id, case_id=None)
            provider = MolmoPointProvider(
                model_directory=model_directory,
                asset_manifest=asset_manifest,
                raw_directory=group / "native",
                generation_limit=CAPS[group_id],
            )
            for case in cases:
                response = None
                try:
                    response = run_case(
                        case,
                        provider=provider,
                        service=service,
                        profile_id=profile_id,
                        ledger=ledger,
                        output=output,
                    )
                except Exception as exc:
                    error = type(exc).__name__
                events = ledger.events_for(case.case_id)
                row = classify_case(case, response, events)
                _write(group / f"result-{case.case_id}.json", row)
                results.append(row)
                if ledger.fatal or any(e["kind"] == "budget_block" for e in events):
                    raise RuntimeError("group accounting/evidence stopped")
    except Exception as exc:
        error = type(exc).__name__
    finally:
        counts = {
            "loads": getattr(provider, "model_loads_started", 0),
            "generations_started": getattr(provider, "generation_calls_started", 0),
            "generations_completed": getattr(provider, "generation_calls_completed", 0),
        }
        if provider is None and (group / "native/load-started.json").exists():
            counts["loads"] = 1
        report = {
            "group_id": group_id,
            "status": "COMPLETED"
            if len(results) == len(GROUPS[group_id]) and not ledger.fatal
            else "INCOMPLETE",
            "error_type": error,
            "actual_counts": counts,
            "results": results,
            "end": _stamp(),
            "hardware_dispatch": False,
        }
        _write(group / "group-end.json", report)
        _manifest(group)
        ledger.close()
    return report


def main(argv: list[str] | None = None) -> int:
    """登记、运行一个固定组或汇总；没有重试/筛选/调大预算参数。"""
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    register = sub.add_parser("preregister")
    register.add_argument("--output", type=Path, required=True)
    register.add_argument("--registry", type=Path, required=True)
    worker = sub.add_parser("run-group")
    worker.add_argument("--group", choices=tuple(GROUPS), required=True)
    for key in [
        "registry",
        "output",
        "model-directory",
        "asset-manifest",
        "model-store",
        "gpu-lock",
    ]:
        worker.add_argument("--" + key, type=Path, required=True)
    worker.add_argument("--profile-id", required=True)
    worker.add_argument("--allow-paid", action="store_true")
    summary = sub.add_parser("summarize")
    summary.add_argument("--registry", type=Path, required=True)
    summary.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.command == "preregister":
        plan = json.loads((ROUND / "plan.json").read_bytes())
        paths = [Path(row["path"]) for row in plan["inputs"]]
        paths += [
            Path(__file__),
            ROOT / "tests/test_molmo_multiscene.py",
            ROUND / "plan.md",
            ROUND / "plan.json",
            ROUND / "implementation/launch_multiscene.py",
            ROOT / "docs/research/molmo-opencv-grounded-planner.md",
        ]
        sources = {str(path.relative_to(ROOT)): _sha(path) for path in paths}
        registry = preregister(
            args.output, build_cases(_sha(ROOT / "assets/robots/franka_panda/scene.xml")), sources
        )
        _write(args.registry, registry)
        print(
            json.dumps(
                {"status": "PREREGISTERED", "cases": 7, "registry_sha256": _sha(args.registry)}
            )
        )
        return 0
    if args.command == "summarize":
        registry = json.loads(args.registry.read_bytes())
        results = [
            json.loads(path.read_bytes()) for path in sorted(args.output.glob("G*/result-*.json"))
        ]
        result = summarize(registry, results)
        _write(args.output / "summary.local.json", result)
        _manifest(args.output)
        print(
            json.dumps(
                {
                    k: result[k]
                    for k in [
                        "total_cases",
                        "passed_cases",
                        "positive_passed",
                        "negative_passed",
                        "all_cases_pass",
                    ]
                }
            )
        )
        return 0 if result["all_cases_pass"] else 2
    report = run_group(
        args.group,
        registry=args.registry,
        output=args.output,
        model_directory=args.model_directory,
        asset_manifest=args.asset_manifest,
        model_store=args.model_store,
        profile_id=args.profile_id,
        gpu_lock=args.gpu_lock,
        allow_paid=args.allow_paid,
    )
    print(
        json.dumps(
            {
                "group_id": args.group,
                "status": report["status"],
                "actual_counts": report["actual_counts"],
            }
        )
    )
    return 0 if report["status"] == "COMPLETED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
