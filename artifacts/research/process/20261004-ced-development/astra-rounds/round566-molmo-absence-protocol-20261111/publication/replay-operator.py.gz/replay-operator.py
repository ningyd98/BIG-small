from pathlib import Path
import hashlib
import json

from cloud_edge_robot_arm.vision import molmo_pointing

root = Path.cwd()
old = Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall')
relative = Path('artifacts/research/process/20261004-ced-development/astra-rounds/round566-molmo-absence-protocol-20261111')
folder = root / relative
plan = json.loads((folder / 'plan.json').read_bytes())
for row in plan['inputs']:
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']

raw = old / 'datasets/model-cache/molmo-multiscene-r558-r561-20261111'
inventory = json.loads((raw / 'raw-manifest.full.local.json').read_bytes())

def verify_originals():
    for item in inventory['files']:
        p = raw / item['path']
        assert p.stat().st_size == item['bytes']
        assert p.stat().st_mtime_ns == item['mtime_ns']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']

verify_originals()
evidence = json.loads((folder / 'original-reproduction.json').read_bytes())
rows = []
for item in evidence['cases']:
    p = Path(item['raw_path'])
    data = p.read_bytes()
    assert len(data) == item['raw_bytes']
    assert hashlib.sha256(data).hexdigest() == item['raw_sha256']
    result = molmo_pointing.parse_native_point(data.decode('utf-8'))
    assert result.status == 'ABSENT'
    assert result.normalized_1000 is None and result.object_index is None and result.error is None
    assert result.raw_text.encode('utf-8') == data
    rows.append({
        'case_id': item['case_id'], 'raw_bytes': len(data), 'raw_sha256': item['raw_sha256'],
        'original_parser_status': item['original_parse_status'], 'derived_parser_status': result.status,
        'coordinates': None, 'object_index': None, 'error': None, 'raw_text_unchanged': True,
        'historical_verdict_unchanged': item['stored_verdict'],
    })
verify_originals()
report = {
    'mode': 'DERIVED_PARSER_REPLAY', 'base_commit': plan['source_base_commit'],
    'parser_source_sha256': hashlib.sha256(Path(molmo_pointing.__file__).read_bytes()).hexdigest(),
    'original_plan_md_sha256': hashlib.sha256((folder / 'plan.md').read_bytes()).hexdigest(),
    'original_plan_json_sha256': hashlib.sha256((folder / 'plan.json').read_bytes()).hexdigest(),
    'frozen_inputs_verified': len(plan['inputs']), 'cases': rows,
    'original_files_unchanged_sha_size_mtime': len(inventory['files']),
    'actual_calls': {'loads': 0, 'generations': 0, 'paid': 0, 'hardware': 0},
    'scope': 'Two historical native texts reparsed only. No new images, inference or seven-case run; old results remain unchanged.',
}
with (folder / 'replay-summary.json').open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'replayed': len(rows), 'derived_absent': sum(r['derived_parser_status'] == 'ABSENT' for r in rows), 'historical_files_unchanged': len(inventory['files']), 'actual_calls': report['actual_calls']}))
