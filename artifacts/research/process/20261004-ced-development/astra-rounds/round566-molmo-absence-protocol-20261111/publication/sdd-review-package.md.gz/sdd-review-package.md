# R566 fresh review package

Base c071bb42ed060ce50f1bd418c350d841bb4ef6ba; head is explicit uncommitted tracked-file diff below (not HEAD..HEAD). Only three code/test files. Plan and spec are in the R566 research directory. Baseline162; declared RED17failed/14passed; GREEN193; Ruff/diffPASS. Two native texts derived replay2ABSENT; original422files unchanged and old independent archive still valid4/7. No actual calls.

```diff
diff --git a/src/cloud_edge_robot_arm/vision/molmo_pointing.py b/src/cloud_edge_robot_arm/vision/molmo_pointing.py
index 723e6b5f..16f923d6 100644
--- a/src/cloud_edge_robot_arm/vision/molmo_pointing.py
+++ b/src/cloud_edge_robot_arm/vision/molmo_pointing.py
@@ -28,7 +28,10 @@ _POINT = re.compile(
     r'<points coords="1[ \t]+([0-9]{1,6})[ \t]+([0-9]{1,4})[ \t]+([0-9]{1,4})">'
     r"([^<>\x00-\x1f]{1,500})</points>"
 )
-_CONTRADICTION = re.compile(r"\b(absent|not\s+visible|no\s+points)\b", re.IGNORECASE)
+_ABSENCE_ALIASES = frozenset({"There are none."})
+_CONTRADICTION = re.compile(
+    r"\b(absent|not\s+visible|no\s+points|there\s+are\s+none)\b", re.IGNORECASE
+)
 
 
 @dataclass(frozen=True)
@@ -65,7 +68,7 @@ class PointProvider(Protocol):
 
 
 def parse_native_point(raw: str) -> NativePointResult:
-    """只接受一个规范点标签或明确 ABSENT，歧义和截断一律拒绝。"""
+    """只接受单个规范点、ABSENT或已验证完整缺失句；歧义和截断均拒绝。"""
     invalid = NativePointResult("INVALID", None, None, raw, "invalid native point grammar")
     if not isinstance(raw, str) or len(raw.encode("utf-8")) > 16384:
         return invalid
@@ -74,7 +77,7 @@ def parse_native_point(raw: str) -> NativePointResult:
         if text.endswith(terminal):
             text = text[: -len(terminal)].strip()
             break
-    if text == "ABSENT":
+    if text == "ABSENT" or text in _ABSENCE_ALIASES:
         return NativePointResult("ABSENT", None, None, raw)
     match = _POINT.fullmatch(text)
     if match is None or _CONTRADICTION.search(match[4]):
diff --git a/tests/test_molmo_grounded_planner.py b/tests/test_molmo_grounded_planner.py
index 4eb1956a..930de803 100644
--- a/tests/test_molmo_grounded_planner.py
+++ b/tests/test_molmo_grounded_planner.py
@@ -928,3 +928,37 @@ def test_fresh_native_failure_keeps_terminal_rejection_and_original_error(monkey
     assert draft.parse_error == "native perception failed: RuntimeError"
     assert draft.observation_evidence["post_cloud_revalidation"]["status"] == "REJECTED"
     assert len(state.calls) == len(state.captures) == 1
+
+
+@pytest.mark.parametrize("absent_at", [1, 2], ids=["target", "destination"])
+def test_native_absence_alias_stops_target_or_destination(monkeypatch, absent_at):
+    import hashlib
+    from dataclasses import replace
+
+    from cloud_edge_robot_arm.cloud.planning.pipeline import PlanningPipeline
+    from cloud_edge_robot_arm.vision.molmo_pointing import parse_native_point
+
+    raw = "There are none.<|im_end|>"
+
+    class AbsencePoints(FixturePoints):
+        def point(self, observation, phrase):
+            bound = super().point(observation, phrase)
+            if len(self.queries) == absent_at:
+                return replace(bound, result=parse_native_point(raw))
+            return bound
+
+    adapter, points, bodies = adapter_fixture(monkeypatch, points=AbsencePoints())
+
+    def forbidden_cloud(*args, **kwargs):
+        raise AssertionError("absence must stop before cloud transport")
+
+    monkeypatch.setattr(adapter.cloud, "_post", forbidden_cloud)
+    response = PlanningPipeline(planner=adapter).process(request_scene())
+    assert response.outcome == "REQUEST_MORE_OBSERVATION"
+    assert response.contract is None and response.dispatch is None
+    assert len(points.queries) == absent_at and bodies == []
+    evidence = response.attempts[-1].draft.observation_evidence
+    assert len(evidence["native_results"]) == absent_at
+    assert evidence["native_results"][-1]["status"] == "ABSENT"
+    assert evidence["native_results"][-1]["normalized_1000"] is None
+    assert evidence["native_results"][-1]["raw_sha256"] == hashlib.sha256(raw.encode()).hexdigest()
diff --git a/tests/test_molmo_pointing.py b/tests/test_molmo_pointing.py
index f408ffaa..ac92ac6a 100644
--- a/tests/test_molmo_pointing.py
+++ b/tests/test_molmo_pointing.py
@@ -244,3 +244,93 @@ def test_decode_failure_retains_generated_tokens(tmp_path, monkeypatch):
     assert (folder / "generation-completed.json").exists()
     assert json.loads((folder / "failure.json").read_text())["generation_calls_completed"] == 1
     assert not (folder / "raw-response.txt").exists()
+
+
+@pytest.mark.parametrize("terminal", ["", "<|im_end|>", "<|endoftext|>"])
+@pytest.mark.parametrize("padding", ["", " \n"])
+def test_native_absence_alias_exact_protocol(terminal, padding):
+    from cloud_edge_robot_arm.vision.molmo_pointing import parse_native_point
+
+    raw = f"{padding}There are none.{terminal}{padding}"
+    result = parse_native_point(raw)
+    assert result.status == "ABSENT"
+    assert result.normalized_1000 is None and result.object_index is None
+    assert result.error is None and result.raw_text == raw
+
+
+@pytest.mark.parametrize(
+    "raw",
+    [
+        "there are none.",
+        "There Are None.",
+        "There are none",
+        "There may be none.",
+        "There are none. More details.",
+        "ABSENT There are none.",
+        "There are non",
+        "There are none.<|im",
+        "There are none.<|im_end|><|im_end|>",
+        "There are none.<|im_end|><|endoftext|>",
+        'There are none.<points coords="1 1 2 3">block</points>',
+        '<points coords="1 1 2 3">block</points>There are none.',
+        '<points coords="1 1 2 3">There are none.</points>',
+        '<points coords="1 1 2 3">red block. There are none.</points>',
+        '<points coords="1 1 2 3">THERE ARE NONE.</points>',
+        '<points coords="1 1 2 3">there  are none.</points>',
+        '<points coords="1 1 2 3">there are   none.</points>',
+        '<points coords="1 1 2 3">There are none but maybe one.</points>',
+    ],
+)
+def test_native_absence_alias_rejects_mixed_or_unknown(raw):
+    from cloud_edge_robot_arm.vision.molmo_pointing import parse_native_point
+
+    result = parse_native_point(raw)
+    assert result.status == "INVALID"
+    assert result.normalized_1000 is None and result.object_index is None
+    assert result.raw_text == raw
+
+
+def test_native_absence_alias_contradiction_is_word_bounded():
+    from cloud_edge_robot_arm.vision.molmo_pointing import parse_native_point
+
+    raw = '<points coords="1 1 2 3">there are nonetheless visible blocks</points>'
+    result = parse_native_point(raw)
+    assert result.status == "POINT" and result.normalized_1000 == (2, 3)
+
+
+@pytest.mark.parametrize("terminal", ["", "<|im_end|>", "<|endoftext|>"])
+def test_native_absence_alias_preserves_evidence(tmp_path, monkeypatch, terminal):
+    from cloud_edge_robot_arm.vision.observations import RGBDObservation
+
+    raw = f"There are none.{terminal}"
+    provider, _, _, _ = native_fixture(tmp_path, monkeypatch)
+    monkeypatch.setattr(provider._processor, "decode", lambda *args, **kwargs: raw)
+    observation = RGBDObservation.model_validate(observation_payload())
+    result = provider.point(observation, "blue block")
+    folder = tmp_path / "raw/request-0001"
+    saved = json.loads((folder / "result.json").read_text())
+    assert result.result.status == saved["native"]["status"] == "ABSENT"
+    assert result.result.raw_text == saved["native"]["raw_text"] == raw
+    assert (folder / "raw-response.txt").read_bytes() == raw.encode()
+    assert result.evidence["raw_sha256"] == hashlib.sha256(raw.encode()).hexdigest()
+    assert (
+        result.observation_checksum
+        == saved["observation_checksum"]
+        == observation.checksum_sha256
+    )
+    assert result.rgb_sha256 == saved["rgb_sha256"] == observation.evidence()["rgb_sha256"]
+    assert result.query_sha256 == saved["query_sha256"] == hashlib.sha256(b"blue block").hexdigest()
+    assert result.result.normalized_1000 is None and result.result.object_index is None
+    assert provider.generation_calls_started == provider.generation_calls_completed == 1
+
+
+def test_native_absence_alias_at_cap_is_invalid(tmp_path, monkeypatch):
+    from cloud_edge_robot_arm.vision.observations import RGBDObservation
+
+    raw = "There are none.<|im_end|>"
+    provider, _, _, _ = native_fixture(tmp_path, monkeypatch, cap=True)
+    monkeypatch.setattr(provider._processor, "decode", lambda *args, **kwargs: raw)
+    result = provider.point(RGBDObservation.model_validate(observation_payload()), "blue block")
+    assert result.result.status == "INVALID"
+    assert result.result.error == "output token cap"
+    assert result.evidence["reached_cap"] is True and result.result.raw_text == raw
```
