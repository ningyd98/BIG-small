from pathlib import Path
import hashlib,json,sys
root=Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall');base=root/'artifacts/research/process/20261004-ced-development/astra-rounds';r=base/'round564-multiscene-native-findings-20261111'; rawroot=root/'datasets/model-cache/molmo-multiscene-r558-r561-20261111'
request=json.loads((r/'request.json').read_text())
for entry in request['inputs']:
 b=Path(entry['path']).read_bytes();assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256'],entry['path']
seen=set()
def audit(event,args):
 if event=='open' and isinstance(args[0],str):
  p=Path(args[0])
  if p.is_absolute() and (p.is_relative_to(rawroot) or p.is_relative_to(root/'src') or p.is_relative_to(root/'scripts')) and not str(p).endswith('.pyc'):seen.add(str(p))
sys.addaudithook(audit)
sys.path[:0]=[str(root),str(root/'src')]
import scripts.probe_molmo_multiscene as m
registry=m._read(rawroot/'registry.json');rows=[]
for item in registry['cases']:
 case=m.CaseSpec.read(item); stored=m._read(rawroot/case.group_id/f'result-{case.case_id}.json')
 response=m.InitialPlanningResponse.model_validate(m._read(rawroot/case.group_id/case.case_id/'pipeline-return.json'))
 events=m._read_events(rawroot,case.case_id)
 computed=m.classify_case(case,response,events,root=rawroot,registry=registry)
 diffs={k:{'stored':stored.get(k),'recomputed':computed.get(k)} for k in set(stored)|set(computed) if stored.get(k)!=computed.get(k)}
 rows.append({'case_id':case.case_id,'stored_verdict':stored['verdict'],'recomputed_verdict':computed['verdict'],'differences':diffs,'recomputed_evidence_errors':computed['evidence_errors']})
checks={g:{'ok':c.ok,'errors':c.errors} for g in m.GROUPS for c in [m.validate_group_evidence(g,root=rawroot,registry=registry)]}
report={'request_inputs_verified':len(request['inputs']),'case_comparisons':rows,'group_checks':checks,'actual_calls':0}
(r/'readonly-case-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
entries=[]
for name in sorted(seen):
 p=Path(name)
 if p.is_file():
  b=p.read_bytes();entries.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(r/'readonly-inputs.json').write_text(json.dumps({'request_inputs_verified':True,'additional_read_inputs':entries},indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
