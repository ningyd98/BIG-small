from pathlib import Path
import base64,hashlib,json,sys
from datetime import datetime
root=Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall');r=root/'artifacts/research/process/20261004-ced-development/astra-rounds/round564-multiscene-native-findings-20261111';rawroot=root/'datasets/model-cache/molmo-multiscene-r558-r561-20261111'
sys.path[:0]=[str(root),str(root/'src')]
import scripts.probe_molmo_multiscene as m
from cloud_edge_robot_arm.vision.tracking import OpenCVTargetTracker,_rgb
from cloud_edge_robot_arm.vision.molmo_pointing import parse_native_point
from cloud_edge_robot_arm.vision.top_grasp import resolve_top_grasp
seen=set()
def read(p):
 seen.add(str(p));return json.loads(p.read_bytes())
def observation(case,group):
 p=rawroot/group/case/'capture-01/request.json';return m.InitialPlanningRequest.model_validate(read(p)).observation
obs=observation('N02','G1');events=[read(p) for p in sorted((rawroot/'events/N02').glob('*.json'))];stage=next(e for e in events if e.get('stage')=='tracker' and e['phase']=='end');start=next(e for e in events if e['op_id']==stage['op_id'] and e['phase']=='start')
def capture_error(factory):
 try:factory();return None
 except ValueError as e:return str(e)
rows=[]
for label,stamp in [('start',start['utc']),('end',stage['utc'])]:
 at=datetime.fromisoformat(stamp)
 class AtBoundary(OpenCVTargetTracker):
  def _binding_reason(self,observation):
   return self._binding_reason_at(observation,at)
 rows.append({'boundary':label,'age_s':(at-obs.captured_at).total_seconds(),'error':capture_error(lambda:AtBoundary(obs,stage['context']['grounding']))})
tracker={'recorded_error':stage['error_message'],'current_clock_error':capture_error(lambda:OpenCVTargetTracker(obs,stage['context']['grounding'])),'boundary_replay':rows,'no_clock_or_payload_mutation':True,'not_exact_internal_clock_claim':True}
absence=[]
for c,g in [('N01','G1'),('N03','G2')]:
 events=[read(p) for p in sorted((rawroot/'events'/c).glob('*.json'))]
 for e in events:
  if e['kind']=='point' and e['phase']=='end' and e.get('status')=='INVALID':
   d=rawroot/e['native_directory'];meta=read(d/'result.json');txt=(d/'raw-response.txt').read_text();seen.add(str(d/'raw-response.txt'))
   parsed=parse_native_point(txt)
   absence.append({'case_id':c,'point_query_ordinal':sum(x['kind']=='point' and x['phase']=='end' and x['seq']<=e['seq'] for x in events),'strict_status':parsed.status,'reached_cap':meta['reached_cap'],'contains_point_markup':'<point' in txt,'exact_absent_after_terminal_strip':txt.strip().removesuffix('<|im_end|>').removesuffix('<|endoftext|>').strip()=='ABSENT','prose_interpretation':'human-readable absence statement; not accepted exact protocol','raw_sha256':hashlib.sha256(txt.encode()).hexdigest()})
obs=observation('P03','G3');ret=read(rawroot/'G3/P03/pipeline-return.json');evidence=ret['attempts'][-1]['draft']['observation_evidence'];print('evidencekeys',list(evidence))
assoc=evidence['target_point_association'];pixel=tuple(evidence['associated_pixel_target']);u,v=pixel;depth=obs.depth_values();rgb=_rgb(obs)
zs=[obs.world_point((x,y)).z for y in range(v-1,v+2) for x in range(u-1,u+2)]
# Export statistics only, never raw RGB/depth arrays or native texts.
p03={'native_pixel':evidence['native_original_pixel_target'],'geometry_pixel':list(pixel),'association_status':assoc['status'],'selection_source':assoc['selected_source'],'pixel_chroma':int(rgb[v,u].max())-int(rgb[v,u].min()),'patch_width':3,'patch_height':3,'patch_valid_depths':all(depth[y*obs.width+x]>0 for y in range(v-1,v+2) for x in range(u-1,u+2)),'world_z_min_m':min(zs),'world_z_max_m':max(zs),'world_z_span_m':max(zs)-min(zs),'unchanged_gate_m':0.008,'recorded_reason':ret['reason'],'reproduced_top_grasp_error':capture_error(lambda:resolve_top_grasp(obs,pixel,0.0)),'support_value_role':'diagnostic support=0 only because flatness rejects before any support-dependent computation; not a reconstructed contract','hypothesis':'native point near visible colored silhouette edge samples mixed top/side surface; depth alone does not prove physical surface identity'}
report={'tracker_time_diagnosis':tracker,'absence_cases':absence,'p03_geometry':p03,'actual_calls':0}
(r/'readonly-findings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
existing=json.loads((r/'readonly-inputs.json').read_text());entries={e['path']:e for e in existing['additional_read_inputs']}
for p in [Path(s) for s in seen]+[root/'src/cloud_edge_robot_arm/vision/revalidation.py',root/'src/cloud_edge_robot_arm/vision/tracking.py',Path(__file__)]:
 b=p.read_bytes();entries[str(p)]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
existing['additional_read_inputs']=list(sorted(entries.values(),key=lambda e:e['path']));(r/'readonly-inputs.json').write_text(json.dumps(existing,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
