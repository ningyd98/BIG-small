from pathlib import Path
import json,io,base64,hashlib
import numpy as np,cv2
from PIL import Image
from cloud_edge_robot_arm.cloud.planning.models import InitialPlanningRequest
from cloud_edge_robot_arm.vision.planner import ground_observation,_target_relief_above_local_support
from cloud_edge_robot_arm.vision.tracking import OpenCVTargetTracker
root=Path('/home/ningyd/.codex/worktrees/molmo-opencv-integration/BIGsmall')
raw=root/'datasets/model-cache/molmo-grounded-r542-20261110/native-01'
request=InitialPlanningRequest.model_validate_json((raw/'raw/capture-01/request.json').read_bytes());o=request.observation
assert base64.b64decode(o.rgb_png_base64)==(raw/'raw/capture-01/rgb.png').read_bytes()
assert base64.b64decode(o.depth_float32_base64)==(raw/'raw/capture-01/depth.f32').read_bytes()
rgb=np.asarray(Image.open(io.BytesIO(base64.b64decode(o.rgb_png_base64))))
hsv=cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV)
mask=(np.ptp(rgb.astype(float),axis=2)>35).astype(np.uint8)
n,labels,stats,centers=cv2.connectedComponentsWithStats(mask,connectivity=8)
origin=(179,109);radius=min(24,max(8,round(min(o.width,o.height)*.08)))
rows=[]
for k in range(1,n):
 x,y,w,h,area=map(int,stats[k]);
 if area<8:continue
 selected=labels==k;ys,xs=np.nonzero(selected);dist2=(xs-origin[0])**2+(ys-origin[1])**2
 dm=cv2.distanceTransform(selected.astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE)
 yy,xx=np.where(dm==dm.max());j=min(range(len(xx)),key=lambda i:((int(xx[i])-origin[0])**2+(int(yy[i])-origin[1])**2,int(yy[i]),int(xx[i])))
 p=(int(xx[j]),int(yy[j]));d=np.array(o.depth_values()).reshape(o.height,o.width)
 row={'component_id':k,'bbox_xywh':[x,y,w,h],'area':area,'centroid':centers[k].tolist(),'minimum_point_distance_px':float(np.sqrt(dist2.min())),'center_pixel':p,'max_interior_distance_px':float(dm.max()),'center_rgb':rgb[p[1],p[0]].tolist(),'center_hsv':hsv[p[1],p[0]].tolist(),'center_world':o.world_point(p).model_dump(),'relief':_target_relief_above_local_support(o,p),'depth_min_max':[float(d[selected].min()),float(d[selected].max())]}
 if np.sqrt(dist2.min())<=radius:
  try:
   grounded=ground_observation(request,o,target_pixel=p,destination_pixel=(130,72),target_label='red block',grasp_profile='mujoco_upright_box_v2',evidence={})
   row['static_grounding']='PASS';row['grounded_evidence']=grounded.evidence
   tracker=object.__new__(OpenCVTargetTracker);tracker.depth_error_bound_m=None;tracker.support_z=grounded.evidence['top_grasp_support_height_m']
   color=tracker._color(rgb,p);geom,reason=tracker._geometry(o,color,target=True)
   row['static_tracker_target_reason']=reason;row['static_tracker_target']=tracker._public(geom) if geom else None
   dest,reason=tracker._geometry(o,tracker._color(rgb,(130,72)),target=False)
   row['static_tracker_destination_reason']=reason;row['static_tracker_destination']=tracker._public(dest) if dest else None
  except ValueError as e:row['static_grounding_error']=str(e)
 rows.append(row)
print(json.dumps({'scope':'OFFLINE_STATIC_DIAGNOSTIC_NOT_CURRENT_ACTIONABLE_OBSERVATION','observation_captured_at_unchanged':o.captured_at.isoformat(),'native_original_pixel':origin,'native_rgb':rgb[109,179].tolist(),'native_hsv':hsv[109,179].tolist(),'native_world':o.world_point(origin).model_dump(),'native_relief':_target_relief_above_local_support(o,origin),'candidate_window_radius_px':radius,'components':rows,'model_loads':0,'generations':0,'cloud_calls':0,'hardware_dispatch':False},ensure_ascii=False,indent=2))
